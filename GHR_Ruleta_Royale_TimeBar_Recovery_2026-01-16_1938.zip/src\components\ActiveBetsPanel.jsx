import React, { useState, useMemo } from 'react'
import { CHIP_RATES } from '../config/GameLimits'
import { calculateWinnings } from '../logic/RouletteUtils'

export const ActiveBetsPanel = ({ currentBets = {}, onClose, viewCurrency = 'USD' }) => {
    const [sortField, setSortField] = useState('amount') // 'amount' | 'potential'
    const [sortDir, setSortDir] = useState('desc') // 'asc' | 'desc'

    // NEW: Toggle between views or just show all? 
    // User asked "in addition to", implying a unified view or appended list.
    // I will append it with a separator.

    // Helper: Calculate Potential Payout Multiplier based on Bet Key
    const getMultiplier = (key) => {
        // Numbers 0-36
        if (!isNaN(parseInt(key)) && parseInt(key) >= 0 && parseInt(key) <= 36) return 36

        // Dozens / Columns: 3x
        if (key.startsWith('DOZ') || key.startsWith('COL')) return 3

        // Simple Chances: 2x
        if (['RED', 'BLACK', 'EVEN', 'ODD', 'LOW', 'HIGH'].includes(key)) return 2

        // Complex Bets
        if (key.includes('SPLIT')) return 18
        if (key.includes('STREET') || key.includes('TRIO')) return 12
        if (key.includes('CORNER') || key.includes('BASKET')) return 9
        if (key.includes('LINE')) return 6

        return 0
    }

    const processedBets = useMemo(() => {
        return Object.entries(currentBets).map(([key, amount]) => {
            const multiplier = getMultiplier(key)
            const potential = amount * multiplier

            // Format Label
            let label = key
            if (!isNaN(parseInt(key))) label = `Apostado: ${key}`
            else if (key === 'DOZ1') label = '1ra Docena'
            else if (key === 'DOZ2') label = '2da Docena'
            else if (key === 'DOZ3') label = '3ra Docena'
            else if (key === 'COL1') label = 'Columna 1'
            else if (key === 'COL2') label = 'Columna 2'
            else if (key === 'COL3') label = 'Columna 3'
            else if (key === 'RED') label = 'Rojo'
            else if (key === 'BLACK') label = 'Negro'
            else if (key === 'EVEN') label = 'Par'
            else if (key === 'ODD') label = 'Impar'
            else if (key === 'LOW') label = 'Bajos (1-18)'
            else if (key === 'HIGH') label = 'Altos (19-36)'
            else if (key === 'ZERO') label = 'Cero (0)'
            else if (key.includes('SPLIT')) label = `Split ${key.replace('SPLIT_', '')}`
            else if (key.includes('STREET')) label = `Calle ${key.replace('STREET_', '')}`
            else if (key.includes('CORNER')) label = `Cuadro ${key.replace('CORNER_', '')}`
            else if (key.includes('LINE')) label = `Linea ${key.replace('LINE_', '')}`

            return {
                key,
                label,
                amount,
                potential,
                type: 'bet'
            }
        })
    }, [currentBets])

    // NEW: Calculate Number Breakdown
    const numberBreakdown = useMemo(() => {
        if (Object.keys(currentBets).length === 0) return []
        const data = []

        // Check all 37 numbers
        for (let i = 0; i <= 36; i++) {
            const potentialWin = calculateWinnings(i, currentBets)
            if (potentialWin > 0) {
                data.push({
                    key: `NUM_COVER_${i}`,
                    label: `Si sale el ${i}`,
                    amount: 0, // No direct bet amount to show here, it's a result
                    potential: potentialWin,
                    type: 'coverage'
                })
            }
        }
        return data
    }, [currentBets])

    const sortedBets = useMemo(() => {
        const directBets = [...processedBets].sort((a, b) => {
            const valA = a[sortField]
            const valB = b[sortField]
            if (sortDir === 'asc') return valA - valB
            return valB - valA
        })

        const coverageBets = [...numberBreakdown].sort((a, b) => {
            // For coverage, usually we just want to sort by payout (potential)
            // But if user selected 'amount', coverage has 0 amount.
            if (sortField === 'amount') return 0 // Keep natural order?
            const valA = a.potential
            const valB = b.potential
            if (sortDir === 'asc') return valA - valB
            return valB - valA
        })

        return { directBets, coverageBets }
    }, [processedBets, numberBreakdown, sortField, sortDir])

    const handleSort = (field) => {
        if (sortField === field) {
            setSortDir(sortDir === 'asc' ? 'desc' : 'asc')
        } else {
            setSortField(field)
            setSortDir('desc')
        }
    }

    const formatMoney = (val) => {
        if (viewCurrency === 'COL') {
            const realVal = val * (CHIP_RATES.COL || 100)
            return '$' + realVal.toLocaleString()
        }
        return '$' + val.toLocaleString()
    }

    if (Object.keys(currentBets).length === 0) return null

    return (
        <div className="active-bets-panel" style={{
            background: 'rgba(0, 0, 0, 0.95)',
            backdropFilter: 'blur(15px)',
            border: '2px solid #555',
            borderRadius: '12px',
            padding: '20px',
            width: '500px',
            maxHeight: '700px',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
            boxShadow: '0 20px 50px rgba(0,0,0,0.9)',
            zIndex: 1000
        }}>
            {/* HEADER */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px', borderBottom: '1px solid #444', paddingBottom: '10px' }}>
                <span style={{ color: '#fff', fontWeight: 'bold', fontSize: '1.2rem' }}>Resumen de Apuestas</span>
                <button onClick={onClose} style={{
                    background: 'transparent', border: 'none', color: '#888', cursor: 'pointer', fontSize: '1.5rem', padding: '0 5px'
                }}>×</button>
            </div>

            {/* TABLE HEADER */}
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', padding: '10px', fontSize: '0.9rem', color: '#aaa', fontWeight: 'bold', borderBottom: '1px solid #333' }}>
                <div>Apuesta</div>
                <div onClick={() => handleSort('amount')} style={{ cursor: 'pointer', textAlign: 'center', color: sortField === 'amount' ? '#ffd700' : '#aaa' }}>
                    Monto {sortField === 'amount' && (sortDir === 'asc' ? '↑' : '↓')}
                </div>
                <div onClick={() => handleSort('potential')} style={{ cursor: 'pointer', textAlign: 'center', color: sortField === 'potential' ? '#4caf50' : '#aaa' }}>
                    Pago {sortField === 'potential' && (sortDir === 'asc' ? '↑' : '↓')}
                </div>
            </div>

            {/* SCROLLABLE LIST */}
            <div style={{ overflowY: 'auto', flex: 1, paddingRight: '5px' }}>

                {/* DIRECT BETS */}
                {sortedBets.directBets.map((bet) => (
                    <div key={bet.key} style={{
                        display: 'grid', gridTemplateColumns: '2fr 1fr 1fr',
                        padding: '10px', fontSize: '1.0rem', borderBottom: '1px solid #333',
                        color: '#eee', alignItems: 'center'
                    }}>
                        <div style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontWeight: '500' }}>{bet.label}</div>
                        <div style={{ textAlign: 'center', color: '#ffd700', fontWeight: 'bold' }}>{formatMoney(bet.amount)}</div>
                        <div style={{ textAlign: 'center', color: '#4caf50', fontWeight: 'bold' }}>{formatMoney(bet.potential)}</div>
                    </div>
                ))}

                {/* SEPARATOR */}
                <div style={{
                    marginTop: '20px', marginBottom: '10px',
                    borderBottom: '1px dashed #444',
                    color: '#00ced1', fontSize: '0.9rem', textTransform: 'uppercase', letterSpacing: '2px', paddingBottom: '5px'
                }}>
                    Desglose por Número
                </div>

                {/* COVERAGE BETS */}
                {sortedBets.coverageBets.map((bet) => (
                    <div key={bet.key} style={{
                        display: 'grid', gridTemplateColumns: '2fr 1fr 1fr',
                        padding: '8px 10px', fontSize: '0.95rem', borderBottom: '1px solid #222',
                        color: '#aad', alignItems: 'center'
                    }}>
                        <div style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{bet.label}</div>
                        <div style={{ textAlign: 'center', color: '#666', fontSize: '0.8em' }}>--</div>
                        <div style={{ textAlign: 'center', color: '#00ced1', fontWeight: 'bold' }}>{formatMoney(bet.potential)}</div>
                    </div>
                ))}

            </div>

            {/* FOOTER TOTAL */}
            <div style={{
                marginTop: '15px', paddingTop: '15px', borderTop: '2px solid #444',
                display: 'flex', justifyContent: 'space-between',
                fontSize: '1.2rem', fontWeight: 'bold'
            }}>
                <span style={{ color: '#aaa' }}>Total Apostado:</span>
                <span style={{ color: '#ffd700' }}>
                    {formatMoney(processedBets.reduce((sum, b) => sum + b.amount, 0))}
                </span>
            </div>
        </div>
    )
}
