import React from 'react'
import { CasinoTable } from './components/CasinoTable'
import { ToastContainer } from './components/ToastContainer'
import './index.css'

function App() {
  return (
    <div className="app-container">
      <ToastContainer />
      <CasinoTable />
    </div>
  )
}

export default App
