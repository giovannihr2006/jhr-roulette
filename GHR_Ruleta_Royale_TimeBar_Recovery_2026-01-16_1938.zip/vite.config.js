import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,      // Aseguramos el puerto estándar
    open: true,     // Esto abre el navegador automáticamente al iniciar
    host: true       // Permite conexión local segura
  }
})