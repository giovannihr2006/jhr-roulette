import React, { useState, useEffect, useRef } from 'react'

export const Draggable = ({ children, id, initialPos = { x: 0, y: 0 }, isEnabled = false, onDragEnd, style = {}, className = '' }) => {
    // Determine initial state with fallbacks
    const [pos, setPos] = useState({
        x: initialPos.x || 0,
        y: initialPos.y || 0,
        w: initialPos.w || 'auto',
        h: initialPos.h || 'auto'
    })

    const [isDragging, setIsDragging] = useState(false)
    const [isResizing, setIsResizing] = useState(false)
    const [rel, setRel] = useState(null) // Relative position cursor-to-element
    const nodeRef = useRef(null)

    // Sync props
    useEffect(() => {
        setPos(prev => ({
            ...prev,
            x: initialPos.x || prev.x || 0,
            y: initialPos.y || prev.y || 0,
            w: initialPos.w || prev.w || 'auto',
            h: initialPos.h || prev.h || 'auto'
        }))
    }, [initialPos])

    useEffect(() => {
        if (!isEnabled) return

        const onMouseMove = (e) => {
            if (isDragging) {
                let newX = e.clientX - rel.x
                let newY = e.clientY - rel.y

                // BOUNDARY CHECKS
                const el = nodeRef.current
                if (el) {
                    const maxX = window.innerWidth - el.offsetWidth
                    const maxY = window.innerHeight - el.offsetHeight
                    newX = Math.max(0, Math.min(newX, maxX))
                    newY = Math.max(0, Math.min(newY, maxY))
                }

                setPos(prev => ({ ...prev, x: newX, y: newY }))
                e.preventDefault()
            } else if (isResizing) {
                // Calculate new size based on mouse position relative to element top-left
                // Top-left is pos.x, pos.y
                const newW = Math.max(50, e.clientX - pos.x)
                const newH = Math.max(50, e.clientY - pos.y)
                setPos(prev => ({ ...prev, w: newW, h: newH }))
                e.preventDefault()
            }
        }

        const onMouseUp = () => {
            if (isDragging || isResizing) {
                setIsDragging(false)
                setIsResizing(false)
                if (onDragEnd) onDragEnd(id, pos)
            }
        }

        document.addEventListener('mousemove', onMouseMove)
        document.addEventListener('mouseup', onMouseUp)

        return () => {
            document.removeEventListener('mousemove', onMouseMove)
            document.removeEventListener('mouseup', onMouseUp)
        }
    }, [isDragging, isResizing, rel, isEnabled, id, pos, onDragEnd])

    const onMouseDown = (e) => {
        if (!isEnabled || e.button !== 0) return

        // Interactive check
        const target = e.target
        if (target.tagName === 'BUTTON' || target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.closest('button')) {
            return
        }

        const rect = nodeRef.current.getBoundingClientRect()
        setRel({
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        })

        // Better initial drag offset logic
        setRel({
            x: e.clientX - pos.x,
            y: e.clientY - pos.y
        })

        setIsDragging(true)
        e.stopPropagation()
    }

    const onResizeStart = (e) => {
        if (!isEnabled) return
        e.stopPropagation() // Prevent drag start
        setIsResizing(true)
    }

    return (
        <div
            ref={nodeRef}
            onMouseDown={onMouseDown}
            className={className}
            style={{
                position: 'absolute',
                left: pos.x,
                top: pos.y,
                width: pos.w,
                height: pos.h,
                cursor: isEnabled ? (isDragging ? 'grabbing' : 'grab') : 'default',
                zIndex: (isDragging || isResizing) ? 2000 : 100,
                border: isEnabled ? '2px dashed #d4af37' : 'none',
                backgroundColor: (pos.w !== 'auto' || pos.h !== 'auto') ? '#000' : (isEnabled ? 'rgba(0,0,0,0.2)' : 'transparent'),
                ...style
            }}
        >
            {/* ID LABEL */}
            {isEnabled && (
                <div style={{
                    position: 'absolute', top: -25, left: 0,
                    background: '#d4af37', color: 'black', padding: '2px 5px',
                    fontSize: '10px', fontWeight: 'bold', borderRadius: '4px',
                    whiteSpace: 'nowrap'
                }}>
                    {id} {pos.w !== 'auto' && `(${Math.round(pos.w)}x${Math.round(pos.h)})`}
                </div>
            )}

            {/* CONTENT */}
            <div style={{ width: '100%', height: '100%', overflow: 'hidden' }}>
                {children}
            </div>

            {/* RESIZE HANDLE */}
            {isEnabled && (
                <div
                    onMouseDown={onResizeStart}
                    style={{
                        position: 'absolute',
                        bottom: 0,
                        right: 0,
                        width: '20px',
                        height: '20px',
                        cursor: 'se-resize',
                        background: 'linear-gradient(135deg, transparent 50%, #d4af37 50%)',
                        zIndex: 5000
                    }}
                />
            )}
        </div>
    )
}
