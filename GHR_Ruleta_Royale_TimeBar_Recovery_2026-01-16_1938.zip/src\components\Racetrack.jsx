import React, { useState, useEffect } from 'react'
import './Racetrack.css'
import { WHEEL_ORDER, getNeighbours } from '../utils/rouletteUtils'

export const Racetrack = ({ onBatchBets, onHoverNumbers, neighborCount = 2, setNeighborCount }) => {

    // --- BET LOGIC DEFINITIONS (Kept for onBatchBets) ---
    // 1. Voisins (22 to 25 clockwise)
    const getVoisins = () => [
        'TRIO_0_2_3', 'TRIO_0_2_3', 'SPLIT_4_7', 'SPLIT_12_15',
        'SPLIT_18_21', 'SPLIT_19_22', 'CORNER_25_26_28_29', 'CORNER_25_26_28_29', 'SPLIT_32_35'
    ]
    const VOISINS_NUMBERS = [22, 18, 29, 7, 28, 12, 35, 3, 26, 0, 32, 15, 19, 4, 21, 2, 25]

    // 2. Tiers (27 to 33)
    const getTiers = () => [
        'SPLIT_5_8', 'SPLIT_10_11', 'SPLIT_13_16', 'SPLIT_23_24', 'SPLIT_27_30', 'SPLIT_33_36'
    ]
    const TIERS_NUMBERS = [27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33]

    // 3. Orphelins (Splits: 17-6, 1-9)
    const getOrphelins = () => ['1', 'SPLIT_6_9', 'SPLIT_14_17', 'SPLIT_17_20', 'SPLIT_31_34']
    const ORPHELINS_NUMBERS = [1, 20, 14, 31, 9, 17, 34, 6]

    // 4. Jeu 0 (12 to 15)
    const getJeuZero = () => ['SPLIT_0_3', 'SPLIT_12_15', 'SPLIT_32_35', '26']
    const ZERO_NUMBERS = [12, 35, 3, 26, 0, 32, 15]


    // --- SVG GEOMETRY CONSTANTS ---
    const CX = 300
    const CY = 120 // Updated to center vertically (was 100 + 20 offset)
    const RX = 280 // Outer radius for zones
    const RY = 60
    const RX_NUM = 240 // Radius for numbers
    const RY_NUM = 50
    const RX_INNER = 180 // Inner radius for zone donut customization if needed
    const RY_INNER = 40

    // --- MANUAL INPUT STATE ---
    const [manualNumber, setManualNumber] = useState('')

    const handleManualChange = (e) => {
        const val = e.target.value
        setManualNumber(val)
        if (val === '') {
            onHoverNumbers([])
            return
        }
        const num = parseInt(val)
        if (!isNaN(num) && num >= 0 && num <= 36) {
            const nums = getNeighbours(num, neighborCount).map(n => parseInt(n))
            onHoverNumbers(nums)
        }
    }

    // Sync highlight
    useEffect(() => {
        if (manualNumber === '') return
        const num = parseInt(manualNumber)
        if (!isNaN(num) && num >= 0 && num <= 36) {
            const nums = getNeighbours(num, neighborCount).map(n => parseInt(n))
            onHoverNumbers(nums)
        }
    }, [manualNumber, neighborCount])


    // --- ROTATION CALCULATION ---
    // Calculates how much to shift angles to center the target number
    let rotationShift = 0
    if (manualNumber !== '') {
        const num = parseInt(manualNumber)
        if (!isNaN(num)) {
            const index = WHEEL_ORDER.indexOf(num)
            if (index !== -1) {
                // Goal: This index should be at -90deg (top)
                // Base angle for index 0 is -90. angle(i) = i*step - 90
                // We add shift S.
                // i*step - 90 + S = -90  => S = - i*step
                rotationShift = - (index * (360 / 37))
            }
        }
    }

    // --- HELPER: GET ANGLE FOR INDEX (including shift) ---
    const getAngleForIndex = (index) => {
        const baseAngle = ((index * (360 / 37)) - 90) + rotationShift
        return baseAngle * (Math.PI / 180)
    }

    // --- HELPER: GET POINT ON ELLIPSE ---
    const getPoint = (rx, ry, angleRad) => {
        return {
            x: CX + rx * Math.cos(angleRad),
            y: CY + ry * Math.sin(angleRad)
        }
    }

    // --- DYNAMIC ZONE PATH GENERATOR ---
    const renderZonePath = (startNum, endNum, label, onClick, onHover, color = 'transparent', stroke = '#444') => {
        const idxStart = WHEEL_ORDER.indexOf(startNum)
        const idxEnd = WHEEL_ORDER.indexOf(endNum)

        // Calculate angles
        let startAngle = getAngleForIndex(idxStart)
        let endAngle = getAngleForIndex(idxEnd)

        // Handle wrapping? 
        // We know Voisins is 22 -> 25. 22 is idx 28, 25 is idx 7.
        // If we just scan indices, we need to span correctly.
        // Let's assume zones are contiguous slices.
        // Voisins: 22..25 is actually a large span wrapping 0.
        // Angle 22 is approx 180deg. Angle 25 is -10deg.
        // We need to draw arc from Start to End CLOCKWISE.

        // Let's calculate start and end points
        // Adjust angles for slight visual padding (half slice width)
        const sliceWidth = (360 / 37) * (Math.PI / 180)
        const sAngle = startAngle - (sliceWidth / 2)
        const eAngle = endAngle + (sliceWidth / 2)

        const pStartOuter = getPoint(RX, RY, sAngle)
        const pEndOuter = getPoint(RX, RY, eAngle)
        const pStartInner = getPoint(RX - 100, RY - 30, sAngle) // Inner boundary for donut effect
        const pEndInner = getPoint(RX - 100, RY - 30, eAngle)

        // LARGE ARC FLAG:
        // Angle difference?
        // Let's normalize angles to 0..2PI relative to start?
        // Simpler: Just check index span.
        let span = 0
        if (idxEnd >= idxStart) span = idxEnd - idxStart
        else span = (37 - idxStart) + idxEnd

        const isLarge = span > 18 ? 1 : 0

        // PATH IS: Move to StartOuter -> Arc to EndOuter -> Line to EndInner -> Arc to StartInner -> Close
        const d = [
            `M ${pStartOuter.x} ${pStartOuter.y}`,
            `A ${RX} ${RY} 0 ${isLarge} 1 ${pEndOuter.x} ${pEndOuter.y}`,
            `L ${pEndInner.x} ${pEndInner.y}`,
            `A ${RX - 100} ${RY - 30} 0 ${isLarge} 0 ${pStartInner.x} ${pStartInner.y}`,
            'Z'
        ].join(' ')

        // Label Position (Midpoint angle)
        // Midpoint angle might need handling for wrap
        // We can just take the point of the middle index number
        const midIndex = (idxStart + Math.floor(span / 2)) % 37
        const midP = getPoint(RX - 30, RY - 10, getAngleForIndex(midIndex))


        return (
            <g>
                <path d={d} className="rt-zone" fill={color} stroke={stroke} strokeWidth="1"
                    onClick={onClick}
                    onMouseEnter={() => onHover(true)}
                    onMouseLeave={() => onHover(false)}
                />
                <text x={midP.x} y={midP.y} className="rt-label" style={{ fill: '#aaa', fontSize: '9px', pointerEvents: 'none' }}>{label}</text>
            </g>
        )
    }

    return (
        <div className="racetrack-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            {/* NEIGHBOR SELECTOR */}
            <div style={{
                display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '5px',
                background: 'rgba(0,0,0,0.5)', padding: '5px 15px', borderRadius: '20px'
            }}>
                <span style={{ color: '#aaa', fontSize: '12px' }}>VECINOS:</span>
                <button onClick={() => setNeighborCount && setNeighborCount(Math.max(1, neighborCount - 1))} style={{ ...btnStyle, width: '20px' }}>-</button>
                <span style={{ color: '#fff', fontWeight: 'bold' }}>{neighborCount}</span>
                <button onClick={() => setNeighborCount && setNeighborCount(Math.min(9, neighborCount + 1))} style={{ ...btnStyle, width: '20px' }}>+</button>

                <div style={{ width: '1px', height: '15px', background: '#555', margin: '0 5px' }}></div>

                {/* MANUAL TARGET INPUT (No Button) */}
                <input
                    type="number"
                    min="0" max="36"
                    placeholder="#"
                    value={manualNumber}
                    onChange={handleManualChange}
                    style={{
                        width: '60px', height: '30px',
                        background: '#222', border: '1px solid #00f3ff',
                        color: '#fff', borderRadius: '4px', textAlign: 'center',
                        fontSize: '16px', fontWeight: 'bold'
                    }}
                />
            </div>

            <svg viewBox="0 0 600 220" className="racetrack-svg" style={{ width: '500px' }}>
                {/* TRACK BACKGROUND (Fixed) */}
                <ellipse cx={CX} cy={CY} rx={RX} ry={RY} fill="transparent" stroke="#111" strokeWidth="42" />

                {/* ZONES (Parametric) */}
                {/* Tiers: 27 to 33 */}
                {renderZonePath(27, 33, 'TIERS', () => onBatchBets(getTiers()), (h) => onHoverNumbers(h ? TIERS_NUMBERS : []))}

                {/* Orphelins 1: 17 to 6 */}
                {renderZonePath(17, 6, 'ORPH', () => onBatchBets(getOrphelins()), (h) => onHoverNumbers(h ? ORPHELINS_NUMBERS : []))}

                {/* Voisins: 22 to 25 */}
                {renderZonePath(22, 25, 'VOISINS', () => onBatchBets(getVoisins()), (h) => onHoverNumbers(h ? VOISINS_NUMBERS : []))}

                {/* Orphelins 2: 1 to 9 */}
                {renderZonePath(1, 9, 'ORPH', () => onBatchBets(getOrphelins()), (h) => onHoverNumbers(h ? ORPHELINS_NUMBERS : []))}

                {/* Jeu 0: 12 to 15 (Overlay, lighter) */}
                {/* We can make it subtle */}

                {/* NUMBERS */}
                {WHEEL_ORDER.map((num, i) => {
                    const angle = getAngleForIndex(i)
                    const p = getPoint(RX_NUM, RY_NUM, angle)
                    return (
                        <text
                            key={num}
                            x={p.x}
                            y={p.y}
                            className="rt-number"
                            style={{
                                fontSize: '11px',
                                fill: num === parseInt(manualNumber) ? '#00f3ff' : '#fff',
                                fontWeight: num === parseInt(manualNumber) ? 'bold' : 'normal',
                                textAnchor: 'middle', dominantBaseline: 'middle', cursor: 'pointer',
                                transition: 'all 0.6s cubic-bezier(0.25, 0.8, 0.25, 1)' // Animate position interpolate? SVG text x/y animates? 
                                // Actually changing x/y props directly might strictly jump unless using Framer Motion.
                                // But browser standard transitions usually handle attr interpolation if CSS?
                                // x/y attributes are not CSS.
                                // We might need <g> transform for smooth anim on individual letters or accept jumpy.
                                // Or use <g style={{transform...}}>
                            }}
                            onClick={(e) => {
                                e.stopPropagation()
                                const bets = getNeighbours(num, neighborCount)
                                onBatchBets(bets)
                            }}
                            onMouseEnter={() => {
                                const nums = getNeighbours(num, neighborCount).map(n => parseInt(n))
                                onHoverNumbers(nums)
                            }}
                            onMouseLeave={() => onHoverNumbers([])}
                        >
                            {num}
                        </text>
                    )
                })}
            </svg>
        </div>
    )
}

const btnStyle = {
    background: '#333', color: '#fff', border: '1px solid #555',
    borderRadius: '4px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center'
}
