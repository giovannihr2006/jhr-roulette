import React from 'react';

const NUMBERS = [
    [1, 2, 3], [4, 5, 6], [7, 8, 9],
    [10, 11, 12], [13, 14, 15], [16, 17, 18],
    [19, 20, 21], [22, 23, 24], [25, 26, 27],
    [28, 29, 30], [31, 32, 33], [34, 35, 36]
];

const REDS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];

const TRAY_STYLE = {
    background: 'linear-gradient(135deg, #1a1a1a 0%, #0e0e0e 100%)',
    border: '2px solid #d4af37',
    borderTop: '2px solid #fecb00',
    borderBottom: '2px solid #8a6e20',
    borderRadius: '8px',
    boxShadow: '0 10px 30px rgba(0,0,0,0.9), 0 0 20px rgba(212, 175, 55, 0.2)',
    padding: '15px',
    width: '280px',
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    position: 'relative', zIndex: 50
};

export const LiveInputControl = ({ onNumberSubmit }) => {

    const getBgColor = (n) => {
        if (n === 0) return '#2e7d32';
        if (REDS.includes(n)) return '#c62828';
        return '#212121';
    };

    return (
        <div style={TRAY_STYLE}>
            <div style={{
                color: '#d4af37', fontFamily: 'Cinzel, serif', fontWeight: 'bold',
                marginBottom: '10px', textTransform: 'uppercase', fontSize: '1.2rem'
            }}>
                📡 Tracker En Vivo
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px', width: '100%' }}>
                {/* Zero spans all columns */}
                <button
                    onClick={() => onNumberSubmit(0)}
                    style={{
                        gridColumn: '1 / -1',
                        padding: '10px',
                        background: '#2e7d32',
                        border: '1px solid #4caf50',
                        borderRadius: '4px',
                        color: 'white', fontWeight: 'bold', fontSize: '1.1rem',
                        cursor: 'pointer',
                        boxShadow: '0 2px 5px rgba(0,0,0,0.5)'
                    }}
                >
                    0
                </button>

                {NUMBERS.map((row, rIdx) => (
                    <React.Fragment key={rIdx}>
                        {row.map(num => (
                            <button
                                key={num}
                                onClick={() => onNumberSubmit(num)}
                                style={{
                                    padding: '10px',
                                    background: getBgColor(num),
                                    border: '1px solid #555',
                                    borderRadius: '4px',
                                    color: 'white', fontWeight: 'bold', fontSize: '1.1rem',
                                    cursor: 'pointer',
                                    boxShadow: '0 2px 5px rgba(0,0,0,0.5)',
                                    transition: 'transform 0.1s'
                                }}
                                onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.95)'}
                                onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
                            >
                                {num}
                            </button>
                        ))}
                    </React.Fragment>
                ))}
            </div>

            <div style={{ marginTop: '10px', fontSize: '0.8rem', color: '#888', fontStyle: 'italic' }}>
                Click para registrar resultado
            </div>
        </div>
    );
};
