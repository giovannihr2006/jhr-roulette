
import React, { useState, useEffect, useRef, useMemo } from 'react'
import { RouletteWheel } from './RouletteWheel'
import { BettingBoard } from './BettingBoard'
import { useFinancialStore } from '../logic/FinancialSimulator'
import { soundManager } from '../utils/SoundManager'
import { dealer } from '../utils/DealerVoice'
import './CasinoTable.css'
import { Draggable } from './Draggable'
import { HelpModal } from './HelpModal'


import { Racetrack } from './Racetrack' // Import was missing!
import { SessionClock } from './SessionClock'
import { StatisticsPanel } from './StatisticsPanel'
import { HistoryPanel } from './HistoryPanel'
import { TopOpportunityWidget } from './TopOpportunityWidget'
import ProjectionsPanel from './ProjectionsPanel'


import { LIMITS, getBetType } from '../config/GameLimits'
import { calculateRisk } from '../utils/BetValidator'
import { useToastStore } from '../logic/ToastStore'
import {
    calculateWinnings,
    calculateCoverage,
    calculateMaxPotentialWin,
    getCoveredNumbers
} from '../logic/RouletteUtils'


// Sequence for index lookup
const WHEEL_NUMBERS = [
    0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23,
    10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
]

const REDS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]

// 1. Matrix definitions
const BALL_TYPES = [
    { name: 'Ivorina (4.5g)', color: '#fffff0' },
    { name: 'Teflón (3.2g)', color: '#ffffff' },
    { name: 'Cerámica (5.8g)', color: '#f0f0e0' },
    { name: 'Metal (8.0g)', color: '#cccccc' }
]

const SPEEDS = [
    { name: '4.2 m/s (15.1 km/h)', laps: 20 },
    { name: '7.5 m/s (27.0 km/h)', laps: 30 },
    { name: '11.3 m/s (40.6 km/h)', laps: 45 }
]

const WHEEL_SPEEDS = [
    { name: 'Lento (L)', laps: 15 },
    { name: 'Normal (N)', laps: 22 },
    { name: 'Rápido (R)', laps: 32 }
]

const START_POINTS = [
    { name: 'Norte 0 Grados', angle: 0 },
    { name: 'Noreste 45 Grados', angle: 45 },
    { name: 'Este 90 Grados', angle: 90 },
    { name: 'Sureste 135 Grados', angle: 135 },
    { name: 'Sur 180 Grados', angle: 180 },
    { name: 'Suroeste 225 Grados', angle: 225 },
    { name: 'Oeste 270 Grados', angle: 270 },
    { name: 'Noroeste 315 Grados', angle: 315 },
]

export const CasinoTable = () => {
    console.log("DEBUG: CasinoTable Mounting...")
    // Rotation State
    const [wheelRotation, setWheelRotation] = useState(0)
    const [ballRotation, setBallRotation] = useState(0)

    // Refs
    const betsTimeoutRef = useRef(null)
    const [ballResetKey, setBallResetKey] = useState(0)

    // Game State
    const [isSpinning, setIsSpinning] = useState(false)
    const isSpinningRef = useRef(isSpinning) // Create ref to track live state

    useEffect(() => {
        isSpinningRef.current = isSpinning
    }, [isSpinning])

    const [autoPlayCount, setAutoPlayCount] = useState(0) // New State for Autoplay
    const [lastWin, setLastWin] = useState(null)
    const [showBall, setShowBall] = useState(false)

    const [lastWinAmount, setLastWinAmount] = useState(0)
    const [potentialWin, setPotentialWin] = useState(0) // New State
    const [showReloadModal, setShowReloadModal] = useState(false) // New State for Reload Modal
    const [reloadAmount, setReloadAmount] = useState('') // Default Reload Amount (User specified: "lo estimo yo", started high)

    // Currency & View State
    const [viewCurrency, setViewCurrency] = useState('COL')

    // Store Selectors
    const gameMode = useFinancialStore(state => state.gameMode)
    const realCapital = useFinancialStore(state => state.realCapital)
    const demoCapital = useFinancialStore(state => state.demoCapital)
    const reloadCapital = useFinancialStore(state => state.reloadCapital)
    const hardReset = useFinancialStore(state => state.hardReset)
    const initialCapital = useFinancialStore(state => state.initialCapital) || 0
    const currentRoundBet = useFinancialStore(state => state.currentRoundBet)
    const sessionStart = useFinancialStore(state => state.sessionStart)

    // Local Ticker for Duration Math
    const [now, setNow] = useState(Date.now())
    useEffect(() => {
        const interval = setInterval(() => setNow(Date.now()), 1000)
        return () => clearInterval(interval)
    }, [])

    // Derived Balance (Safer than store getter)
    const balance = gameMode === 'REAL' ? realCapital : demoCapital

    // --- MAX BALANCE TRACKING ---
    const [maxBalance, setMaxBalance] = useState(balance)
    const [isNewRecord, setIsNewRecord] = useState(false)
    const [showRecordModal, setShowRecordModal] = useState(false)

    useEffect(() => {
        if (balance > maxBalance) {
            setMaxBalance(balance)
            setIsNewRecord(true)
            setShowRecordModal(true) // <--- Trigger Pop-up
            soundManager.playRecord()
            setTimeout(() => setIsNewRecord(false), 3000)
        }
    }, [balance, maxBalance])
    // ----------------------------

    console.log("DEBUG: Store Selectors OK", { gameMode, balance })

    // Actions & State
    const placeBet = useFinancialStore(state => state.placeBet)
    const refundBet = useFinancialStore(state => state.refundBet)
    const resolveRound = useFinancialStore(state => state.resolveRound)
    const transactionLog = useFinancialStore(state => state.transactionLog || [])
    const withdraw = useFinancialStore(state => state.withdraw)
    const [showWithdrawModal, setShowWithdrawModal] = useState(false)
    const [showResetModal, setShowResetModal] = useState(false) // New State for Reset Modal
    const [withdrawAmount, setWithdrawAmount] = useState('')
    const [buyInAmount, setBuyInAmount] = useState('') // New State for Buy In Input

    // Reset amount when opening modal
    useEffect(() => {
        if (showWithdrawModal) setWithdrawAmount('')
    }, [showWithdrawModal])

    const handleWithdrawSubmit = () => {
        console.log("DEBUG: Attempting withdrawal...", { withdrawAmount, balance })
        const amount = Number(withdrawAmount)
        if (!amount || amount <= 0) {
            addToast("Por favor ingresa un monto válido", "error")
            return
        }

        const rate = RATES[viewCurrency] || 1
        const amountBase = amount / rate

        const result = withdraw(amountBase)
        console.log("DEBUG: Withdraw Result:", result)

        if (result.success) {
            setShowWithdrawModal(false)
            addToast(`Retiro Exitoso: -${formatValue(amountBase)}`, "success")
            soundManager.playChip()
        } else {
            console.error("Disturbing failure:", result.error)
            if (result.error === 'INSUFFICIENT_FUNDS') addToast("Saldo insuficiente para este retiro", "error")
            else addToast("Error al procesar el retiro", "error")
        }
    }

    // Force Clean Slate on Logic Unit Mount if empty history (Solves Ghost State)
    // Force Clean Slate logic removed to support Persistence
    // useEffect(() => { ... }, [])

    // Betting State
    const [currentBets, setCurrentBets] = useState({})
    // Initialize lastBets from localStorage if available
    const [lastBets, setLastBets] = useState(() => {
        try {
            const saved = localStorage.getItem('casinoLastBets')
            return saved ? JSON.parse(saved) : {}
        } catch {
            return {}
        }
    })

    // Save lastBets to localStorage whenever it changes
    useEffect(() => {
        localStorage.setItem('casinoLastBets', JSON.stringify(lastBets))
    }, [lastBets])
    const [betHistory, setBetHistory] = useState([]) // For Undo
    const numberHistory = useFinancialStore(state => state.numberHistory || [])


    const [selectedChip, setSelectedChip] = useState(5)
    // Wheel Highlight Sync
    const [hoveredNumbers, setHoveredNumbers] = useState([])

    // MODALS
    const [showHistory, setShowHistory] = useState(false)
    const [showBankruptcy, setShowBankruptcy] = useState(false)

    // Bankruptcy Check
    // Bankruptcy Check - Force open ONLY if it wasn't already acted upon? 
    // Actually, let's remove the auto-force to allow "Zero Balance" browsing.
    // Use the game result logic to trigger it instead, or just let them click "Recargar".
    // Or keep it simple: If balance drops to 0, show it ONCE.
    useEffect(() => {
        if (balance < 1 && currentRoundBet === 0 && !isSpinning && !buyInAmount) {
            // Logic to show it once? 
            // For now, let's DISABLE auto-show to respect the user's wish to input 0.
            // They can click "Recargar" if they need money.
            // OR: Only show if they try to bet?
        }
    }, []) // Disable listeners

    // DEFAULT POSITIONS (Updated for 17-inch "Professional Elite" Layout)
    // DEFAULT POSITIONS (Updated to User-Defined "Gold Master" Layout v9)
    // CAPTURED: 2026-01-09T11:40
    const DEFAULT_POSITIONS = {
        paytable: { x: 20, y: 20 },
        layoutControls: { x: 80, y: 18 },
        history: { x: 876, y: 703 },
        statistics: { x: 1972, y: 35 },
        opportunity: { x: 393, y: 18 },
        telemetry: { x: 34, y: 921 },
        wheel: { x: 20, y: 80 },
        racetrack: { x: 20, y: 687 },
        banking: { x: 1578, y: 35 },
        clock: { x: 1255, y: 679 },
        projections: { x: 553, y: 700 },
        win: { x: 1550, y: 400 },
        board: { x: 626, y: 117 },
        controls: { x: 629, y: 521 },
        autoplay: { x: 676, y: 44 },
        chips: { x: 1172, y: 513 }
    }

    // LAYOUT STATE
    const [isEditMode, setIsEditMode] = useState(false)
    const [showHelp, setShowHelp] = useState(false)
    const addToast = useToastStore(state => state.addToast)

    // Load positions from localStorage or default
    const [positions, setPositions] = useState(() => {
        try {
            const saved = localStorage.getItem('casinoLayout_v9') // User Gold Master V9
            if (saved) {
                const parsed = JSON.parse(saved)
                // SANITY CHECK: If "wheel" is at 0,0, reset.
                if (parsed.wheel && parsed.wheel.x === 0 && parsed.wheel.y === 0) {
                    return DEFAULT_POSITIONS
                }
                return { ...DEFAULT_POSITIONS, ...parsed }
            }
            return DEFAULT_POSITIONS
        } catch (e) {
            console.warn("Failed to load layout", e)
            return DEFAULT_POSITIONS
        }
    })

    const onUpdatePos = (id, newPos) => {
        if (!newPos || isNaN(newPos.x) || isNaN(newPos.y)) return // Sanity Check

        setPositions(prev => {
            const next = { ...prev, [id]: newPos }
            localStorage.setItem('casinoLayout_v9', JSON.stringify(next))
            return next
        })
    }

    const resetLayout = () => {
        if (confirm("¿Restaurar diseño de fábrica?")) {
            setPositions(DEFAULT_POSITIONS)
            localStorage.removeItem('casinoLayout_v9')
        }
    }

    // Currency Exchange Rates (Base: 1 Logic Unit = 1 USD)
    const RATES = {
        COL: 100,  // User requested 100
        USA: 1,
        EUR: 0.92  // ~0.92 EUR per USD
    }

    const formatValue = (creditValue) => {
        if (creditValue === undefined || creditValue === null || isNaN(creditValue)) return "$0"

        const val = creditValue * (RATES[viewCurrency] || 1) // Safety fallback

        if (viewCurrency === 'COL') return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(val)
        if (viewCurrency === 'USA') return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val)
        if (viewCurrency === 'EUR') return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(val)
        return val.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 })
    }

    const formatBalance = (creditValue) => {
        if (creditValue === undefined || creditValue === null || isNaN(creditValue)) return "$0.00"
        return formatValue(creditValue)
    }

    // Physics Debug State (Safe Init)
    const [physicsState, setPhysicsState] = useState(() => ({
        ballType: BALL_TYPES[0],
        ballSpeed: SPEEDS[0],
        wheelSpeed: '---',
        wheelSpeedObject: WHEEL_SPEEDS[0],
        startPoint: START_POINTS[0],
        wheelDirection: 'Horario',
        ballDirection: 'Anti-Horario'
    }))
    console.log("DEBUG: Physics Init OK", physicsState)

    // Init Random Physics on Mount
    const randomizePhysicsDisplay = () => {
        const pBall = BALL_TYPES[Math.floor(Math.random() * BALL_TYPES.length)]
        const pSpeed = SPEEDS[Math.floor(Math.random() * SPEEDS.length)]
        const pWheel = WHEEL_SPEEDS[Math.floor(Math.random() * WHEEL_SPEEDS.length)]
        const pStart = START_POINTS[Math.floor(Math.random() * START_POINTS.length)]
        const pDirVal = Math.random() > 0.5 ? 1 : -1

        const dist = pWheel.laps * 2.5
        const mps = (dist / 12.5).toFixed(1)

        setPhysicsState({
            ballType: pBall,
            ballSpeed: pSpeed,
            wheelSpeed: `${pWheel.name} - ${mps} m/s`,
            wheelSpeedObject: pWheel,
            startPoint: pStart,
            wheelDirection: pDirVal === 1 ? 'Horario ↻' : 'Anti-Horario ↺',
            ballDirection: pDirVal === 1 ? 'Anti-Horario ↺' : 'Horario ↻'
        })
    }
    useEffect(() => {
        randomizePhysicsDisplay()
    }, [])



    // --- HELPER FUNCTIONS (Moved to avoid hoisting issues) ---
    const resolvePayouts = (winningNumber) => {
        const totalWinnings = calculateWinnings(winningNumber, currentBets)

        if (totalWinnings > 0) {
            soundManager.playWin(totalWinnings)
            // Voice Announcement for Profit
            const totalBet = Object.values(currentBets).reduce((a, b) => a + b, 0)
            if (totalWinnings > totalBet) {
                // Small delay to let the win sound start and "Winner is X" finish
                setTimeout(() => dealer.profitWin(), 2500)
            }
            setLastWinAmount(totalWinnings)
        } else {
            setLastWinAmount(0)
        }

        const roundBets = { ...currentBets }
        resolveRound(totalWinnings, winningNumber, roundBets)
        setCurrentBets({})
    }

    const handleRepeat = () => {
        if (isSpinning || Object.keys(lastBets).length === 0) return

        const cost = Object.values(lastBets).reduce((a, b) => a + b, 0)
        const result = placeBet(cost, 'BATCH')

        if (!result.success) {
            if (result.error === 'INSUFFICIENT_FUNDS') addToast("Saldo insuficiente para repetir apuesta", 'error')
            else if (result.error === 'MAX_TOTAL_EXCEEDED') addToast(`Límite total de mesa excedido ($${result.limit})`, 'error')
            return
        }

        setCurrentBets(prev => {
            const next = { ...prev }
            Object.entries(lastBets).forEach(([id, amount]) => {
                next[id] = (next[id] || 0) + amount
            })
            return next
        })

        setBetHistory(prev => [...prev, { bets: lastBets, totalCost: cost }])
        soundManager.playChip()
    }

    // Spin Logic
    // Initialize Dealer
    useEffect(() => {
        // Small delay to allow voices to load
        setTimeout(() => dealer.welcome(), 1000)
    }, [])

    const handleSpin = () => {
        if (isSpinning) return

        // 1. Randomize for this spin
        const pBall = BALL_TYPES[Math.floor(Math.random() * BALL_TYPES.length)]
        const pBallSpeed = SPEEDS[Math.floor(Math.random() * SPEEDS.length)]
        const pWheelSpeed = WHEEL_SPEEDS[Math.floor(Math.random() * WHEEL_SPEEDS.length)]
        const pStart = START_POINTS[Math.floor(Math.random() * START_POINTS.length)]
        const pDirVal = Math.random() > 0.5 ? 1 : -1

        const wheelDirName = pDirVal === 1 ? 'Horario' : 'Anti-Horario'
        const ballDirName = pDirVal === 1 ? 'Anti-Horario' : 'Horario'

        const wheelLaps = pWheelSpeed.laps
        const dist = wheelLaps * 2.5
        const mps = (dist / 12.5).toFixed(1)
        const kmh = (mps * 3.6).toFixed(1)

        setPhysicsState({
            ballType: pBall,
            ballSpeed: pBallSpeed,
            wheelSpeed: `${mps} m/s (${kmh} km/h)`,
            wheelSpeedObject: pWheelSpeed,
            startPoint: pStart,
            wheelDirection: wheelDirName,
            ballDirection: ballDirName
        })

        // 2. Setup
        try {
            soundManager.playSpinStart() // AUDIO
            soundManager.playBallLoop() // NEW: Start rolling sound
            // Physics parameters
            // ...

            dealer.noMoreBets()
            setIsSpinning(true)

            // Save for Repeat
            if (Object.keys(currentBets).length > 0) {
                setLastBets(currentBets)
            }
            setBetHistory([]) // Clear undo history for new round

            setLastWin(null)

            setLastWinAmount(0)
            setShowBall(true)
            setBallResetKey(prev => prev + 1)
            setBallRotation(pStart.angle)

            // 3. Winner
            let winningNumber = WHEEL_NUMBERS[Math.floor(Math.random() * WHEEL_NUMBERS.length)]

            // --- VERIFICATION INSTRUMENTATION ---
            if (window.forceWinningNumber !== undefined && window.forceWinningNumber !== null) {
                const forced = parseInt(window.forceWinningNumber)
                if (WHEEL_NUMBERS.includes(forced)) {
                    console.log("DEBUG: Forcing winning number to", forced)
                    winningNumber = forced
                }
            }
            // ------------------------------------
            const winningIndex = WHEEL_NUMBERS.indexOf(winningNumber)

            // 4. Deltas
            const wheelDelta = pDirVal * ((wheelLaps * 360) + Math.random() * 360)
            const nextWheelRotation = wheelRotation + wheelDelta

            const ballDirVal = -pDirVal
            const totalBallLaps = pBallSpeed.laps
            const ballTotalDegrees = totalBallLaps * 360
            const wedgeAngle = winningIndex * (360 / 37)
            const targetWorldAngle = nextWheelRotation + wedgeAngle
            const idealEnd = pStart.angle + (ballDirVal * ballTotalDegrees)
            const diff = idealEnd - targetWorldAngle
            const rounds = Math.round(diff / 360)
            const nextBallRotation = targetWorldAngle + (rounds * 360)

            // 5. Animate
            setTimeout(() => {
                setWheelRotation(nextWheelRotation)
                setBallRotation(nextBallRotation)
            }, 100)

            // 6. Cleanup
            setTimeout(() => {
                try {
                    setIsSpinning(false)
                    // Voice Color Logic: 0 is usually 'Verde' or special.
                    const color = winningNumber === 0 ? 'Verde' : (REDS.includes(winningNumber) ? 'Rojo' : 'Negro')

                    dealer.winner(winningNumber, color)

                    setLastWin(winningNumber)
                    resolvePayouts(winningNumber)

                    // Clear highlights after 5 seconds
                    betsTimeoutRef.current = setTimeout(() => {
                        // setLastWin(null) // KEEP WINNER ON SCREEN
                        // setLastWinAmount(0) // Keep amount too? User said "No refresca", maybe they want to see it.
                        // Let's keep lastWin visible. Reset amount? Usually amount resets. 
                        // Let's keep amount too for now, or maybe reset it. 
                        // User request "No refresca" -> "It doesn't refresh". 
                        // If it disappears, they might think it's broken.

                        setBallResetKey(prev => prev + 1)
                        if (!isSpinningRef.current) { // Check LIVE state
                            dealer.betsOpen()
                        }
                    }, 5000)

                } catch (error) {
                    console.error("Error resolving spin:", error)
                    setIsSpinning(false) // Force reset on error
                }
            }, 12500)

        } catch {
            console.error("Critical error in spin setup")
            setIsSpinning(false)
        }
    }

    // --- AUTOPLAY LOGIC ---
    useEffect(() => {
        if (!isSpinning && autoPlayCount > 0) {
            const timer = setTimeout(() => {
                // 1. Repeat Bets
                if (Object.keys(currentBets).length === 0 && Object.keys(lastBets).length > 0) {
                    handleRepeat()
                } else if (Object.keys(currentBets).length === 0) {
                    // No bets to repeat and empty table? Stop.
                    addToast("Autoplay detenido: No hay apuestas para repetir", "error")
                    setAutoPlayCount(0)
                    return
                }

                // 2. Spin
                // Ensure we call spin only if valid
                handleSpin()

                // 3. Decrement
                setAutoPlayCount(prev => prev - 1)

            }, 2000) // 2 seconds between spins
            return () => clearTimeout(timer)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isSpinning, autoPlayCount])

    console.log("DEBUG RENDER: Bets:", Object.keys(currentBets).length, "SelectedChip:", selectedChip)

    // DEBUG OVERLAY




    // --- POTENTIAL WIN LOGIC ---
    const [bestPayout, setBestPayout] = useState({ amount: 0, numbers: [] })

    useEffect(() => {
        if (Object.keys(currentBets).length > 0) {
            const { maxWin, bestNumbers } = calculateMaxPotentialWin(currentBets)
            setBestPayout({ amount: maxWin, numbers: bestNumbers })

            // Still allow hover override if hovering a specific number? 
            // Or just show Max Win permanently as requested?
            // "PAGO POTENCIAL SIEMPRE VISIBLE... INDICANDO EL NUMERO QUE MAS PAGA"

            // Check hover for interactive feedback
            if (hoveredNumbers.length === 1) {
                const hoverWin = calculateWinnings(hoveredNumbers[0], currentBets)
                setPotentialWin(hoverWin)
            } else {
                setPotentialWin(0) // Reset hover
            }
        } else {
            setBestPayout({ amount: 0, numbers: [] })
            setPotentialWin(0)
        }
    }, [currentBets, hoveredNumbers])

    const handlePlaceBet = (betId) => {
        console.log("DEBUG EVENT: handlePlaceBet called with", betId, "SelectedChip:", selectedChip)
        if (isSpinning) {
            console.log("DEBUG EVENT: Spin in progress, bet ignored")
            return
        }

        // --- LIMITS & VALIDATION 1: Chips ---
        const limits = LIMITS[gameMode]

        // 1. Min Bet
        if (selectedChip < limits.MIN_BET) {
            console.warn("DEBUG EVENT: Min bet rejection", selectedChip, limits.MIN_BET)
            addToast(`Mínimo de apuesta es ${limits.MIN_BET}`, 'error')
            return
        }

        // 2. Max Total Bet Prediction
        const predictedTotalBet = currentRoundBet + selectedChip // Approx, store might lag? No, store is sync enough usually or passed via prop.
        if (predictedTotalBet > limits.MAX_TOTAL_BET) {
            addToast(`Límite total de apuesta excedido (${limits.MAX_TOTAL_BET})`, 'error')
            return
        }

        // 3. Max Positions
        const currentPositions = Object.keys(currentBets).length
        if (!currentBets[betId] && currentPositions >= limits.MAX_POSITIONS) {
            alert(`Máximo de ${limits.MAX_POSITIONS} posiciones permitidas.`)
            return
        }

        // 4. THE PRO CHECK: Max Potential Win ("Worst Case")
        // Create a temporary state of what bets WOULD be
        const nextBets = { ...currentBets, [betId]: (currentBets[betId] || 0) + selectedChip }
        const { maxWin } = calculateRisk(nextBets)

        if (maxWin > limits.MAX_WIN_PER_SPIN) {
            addToast(`Esta apuesta excede el pago máximo permitido de la mesa (${limits.MAX_WIN_PER_SPIN}).`, 'error')
            return
        }

        // Proceed
        const betType = getBetType(betId)
        const currentBetOnSpot = currentBets[betId] || 0
        const result = placeBet(selectedChip, betType, currentBetOnSpot)

        if (!result.success) {
            if (result.error === 'INSUFFICIENT_FUNDS') {
                setShowReloadModal(true) // Trigger Modal
                soundManager.playError()
            } else if (result.error === 'MAX_TOTAL_EXCEEDED') {
                addToast(`Límite total de mesa excedido ($${result.limit})`, 'error')
            } else if (result.error === 'LIMIT_EXCEEDED') {
                addToast(`Apuesta máxima para ${result.type} es $${result.limit}`, 'error')
            }
            return
        }

        try {
            if (soundManager && soundManager.playChip) {
                soundManager.playChip()
            }
        } catch (e) {
            console.error(e)
        }

        setCurrentBets(prev => ({
            ...prev,
            [betId]: (prev[betId] || 0) + selectedChip
        }))

        // History for Undo
        setBetHistory(prev => [...prev, { bets: { [betId]: selectedChip }, totalCost: selectedChip }])
    }

    const handleBatchBets = (betsToPlace) => {
        // betsToPlace: Array of betIds ['1', 'SPLIT_1_2', ...]
        if (isSpinning) return
        const totalCost = betsToPlace.length * selectedChip

        const success = placeBet(totalCost)
        if (!success) {
            addToast(`Saldo insuficiente para esta apuesta completa ($${totalCost})`, 'error')
            return
        }

        soundManager.playChip()

        const newBatch = {}
        betsToPlace.forEach(id => {
            newBatch[id] = selectedChip
        })

        setCurrentBets(prev => {
            const next = { ...prev }
            betsToPlace.forEach(id => {
                next[id] = (next[id] || 0) + selectedChip
            })
            return next
        })

        setBetHistory(prev => [...prev, { bets: newBatch, totalCost: totalCost }])
    }

    // --- NEW BETTING CONTROLS ---

    const handleUndo = () => {
        if (isSpinning || betHistory.length === 0) return

        const lastAction = betHistory[betHistory.length - 1]

        // 1. Refund
        refundBet(lastAction.totalCost)

        // 2. Remove bets
        setCurrentBets(prev => {
            const next = { ...prev }
            Object.entries(lastAction.bets).forEach(([id, amount]) => {
                if (next[id]) {
                    next[id] -= amount
                    if (next[id] <= 0) delete next[id]
                }
            })
            return next
        })

        // 3. Update History
        setBetHistory(prev => prev.slice(0, -1))
        soundManager.playChip() // Maybe a different sound?
    }

    const handleClear = () => {
        if (isSpinning || Object.keys(currentBets).length === 0) return

        // Refund total current bet
        refundBet(currentRoundBet)

        setCurrentBets({})
        setBetHistory([])
        soundManager.playChip()
    }



    const handleDouble = () => {
        if (isSpinning || Object.keys(currentBets).length === 0) return

        // Cost is equal to current currentRoundBet (since we are duplicating everything)
        // Wait, currentRoundBet is in store. 
        const cost = currentRoundBet

        const result = placeBet(cost, 'BATCH')
        if (!result.success) {
            if (result.error === 'INSUFFICIENT_FUNDS') addToast("Saldo insuficiente para doblar", 'error')
            else if (result.error === 'MAX_TOTAL_EXCEEDED') addToast(`Límite total de mesa excedido ($${result.limit})`, 'error')
            return
        }

        const addedBets = { ...currentBets } // We are adding exactly what we have

        setCurrentBets(prev => {
            const next = { ...prev }
            Object.keys(next).forEach(key => {
                next[key] *= 2
            })
            return next
        })

        setBetHistory(prev => [...prev, { bets: addedBets, totalCost: cost }])
        soundManager.playChip()
    }



    return (
        <div className="casino-table" style={{ display: 'block' }}> {/* Switch to block for absolute children */}
            {/* BRANDING HEADER */}
            <div style={{
                position: 'fixed',
                top: '20px',
                left: '50%',
                transform: 'translateX(-50%)',
                zIndex: 4000,
                color: '#d4af37',
                fontFamily: 'Times New Roman, serif', // Use standard font or import one if possible, staying safe.
                fontSize: '1.8rem',
                letterSpacing: '4px',
                textShadow: '0 2px 10px rgba(0,0,0,0.9), 0 0 20px rgba(212, 175, 55, 0.4)',
                pointerEvents: 'none',
                borderBottom: '1px solid rgba(212, 175, 55, 0.3)',
                paddingBottom: '5px',
                textTransform: 'uppercase',
                whiteSpace: 'nowrap'
            }}>
                GHR Ruleta Royale
            </div>


            {/* LOCK/UNLOCK BUTTON - Now Draggable */}
            <Draggable id="layoutControls" isEnabled={isEditMode} initialPos={positions.layoutControls} onDragEnd={onUpdatePos}
                style={{ zIndex: 5000 }} // Keep on top
            >
                <div style={{ display: 'flex', gap: '10px' }}>
                    {isEditMode && (
                        <button
                            onClick={resetLayout}
                            style={{
                                background: '#d4af37', color: 'black', border: 'none',
                                padding: '10px 20px', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold'
                            }}
                        >
                            ↺ RESET
                        </button>
                    )}
                    <button
                        onClick={() => setIsEditMode(!isEditMode)}
                        style={{
                            background: isEditMode ? '#ff4444' : '#444',
                            color: 'white', border: '1px solid #fff',
                            padding: '10px 20px', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold'
                        }}
                    >
                        {isEditMode ? '🔒 BLOQUEAR DISEÑO' : '🔓 MOVER ELEMENTOS'}
                    </button>
                </div>
            </Draggable>

            {/* 1. WHEEL SECTION */}
            <Draggable id="wheel" isEnabled={isEditMode} initialPos={positions.wheel} onDragEnd={onUpdatePos}>
                <RouletteWheel
                    wheelRotation={wheelRotation}
                    ballRotation={ballRotation}
                    showBall={showBall}
                    ballResetKey={ballResetKey}
                    highlightedNumbers={hoveredNumbers}
                    placedNumbers={useMemo(() => getCoveredNumbers(currentBets), [currentBets])} // NEW PROP
                    size={500}
                    lastWin={lastWin} // Passed here
                />
            </Draggable>

            {/* 2. BOARD SECTION */}
            <Draggable id="board" isEnabled={isEditMode} initialPos={positions.board} onDragEnd={onUpdatePos}>
                <div style={{ transform: 'scale(0.9)', transformOrigin: 'top left', width: '900px' }}> {/* Scale down slightly to fit */}
                    <BettingBoard
                        bets={currentBets}
                        onPlaceBet={handlePlaceBet}
                        onBatchBet={handleBatchBets}
                        lastWin={lastWin}
                        onHoverNumbers={setHoveredNumbers}
                        history={numberHistory}
                    />
                </div>
            </Draggable>



            {/* 4. TELEMETRY */}
            <Draggable id="telemetry" isEnabled={isEditMode} initialPos={positions.telemetry} onDragEnd={onUpdatePos}>
                <div style={{
                    fontSize: '13px', color: '#ccc', background: 'linear-gradient(to bottom, #222, #111)',
                    padding: '15px', borderRadius: '8px', textAlign: 'left',
                    border: '1px solid #555', boxShadow: '0 4px 10px rgba(0,0,0,0.5)',
                    minWidth: '300px', fontFamily: 'monospace'
                }}>
                    <div style={{ marginBottom: 8, color: '#d4af37', textAlign: 'center', textTransform: 'uppercase', letterSpacing: '1px' }}>
                        🔬 Telemetría
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '5px' }}>
                        <div>Bola:</div> <div style={{ color: 'white' }}>{physicsState.ballType.name}</div>
                        <div>Salida:</div> <div style={{ color: 'white' }}>{physicsState.startPoint.name}</div>
                        <div style={{ borderTop: '1px solid #444', paddingTop: 5 }}>Sentido Bola:</div>
                        <div style={{ borderTop: '1px solid #444', paddingTop: 5, color: '#8f8' }}>{physicsState.ballDirection}</div>
                        <div>Vel. Bola:</div> <div style={{ color: '#4ff' }}>{physicsState.ballSpeed.name}</div>
                        <div style={{ borderTop: '1px solid #444', paddingTop: 5 }}>Sentido Cilindro:</div>
                        <div style={{ borderTop: '1px solid #444', paddingTop: 5, color: '#f88' }}>{physicsState.wheelDirection}</div>
                        <div>Vel. Cil:</div> <div style={{ color: '#f88' }}>{physicsState.wheelSpeed}</div>
                        <div style={{ gridColumn: '1 / -1', marginTop: 10, paddingTop: 10, borderTop: '1px dashed #555', textAlign: 'center', color: '#aaa' }}>
                            Permutaciones: <span style={{ color: '#fff', fontWeight: 'bold' }}>432</span>
                        </div>
                    </div>
                </div>
            </Draggable>

            {/* NEW: SESSION CLOCK (Top Right) */}
            <Draggable id="clock" isEnabled={isEditMode} initialPos={positions.clock || { x: 1600, y: 20 }} onDragEnd={onUpdatePos}>
                <SessionClock />
            </Draggable>

            {/* 5. PAYTABLE (INFO) */}
            <Draggable id="paytable" isEnabled={isEditMode} initialPos={positions.paytable} onDragEnd={onUpdatePos}>
                <div
                    onClick={() => setShowHelp(true)}
                    style={{
                        width: '40px', height: '40px', borderRadius: '50%',
                        background: '#222', border: '2px solid #d4af37',
                        color: '#d4af37', display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: '20px', fontWeight: 'bold', cursor: 'pointer',
                        boxShadow: '0 0 10px rgba(0,0,0,0.5)', transition: 'transform 0.2s'
                    }}
                    onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.1)'}
                    onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
                    title="Ver Guía de Apuestas"
                >
                    ?
                </div>
            </Draggable>



            {/* NEW: STATISTICS PANEL */}
            <Draggable id="statistics" isEnabled={isEditMode} initialPos={positions.statistics} onDragEnd={onUpdatePos}>
                <StatisticsPanel />
            </Draggable>



            {/* NEW: RACETRACK */}
            <Draggable id="racetrack" isEnabled={isEditMode} initialPos={positions.racetrack} onDragEnd={onUpdatePos}>
                <div style={{ transform: 'scale(1.0)', transformOrigin: 'top left' }}>
                    <Racetrack onBatchBets={handleBatchBets} onHoverNumbers={setHoveredNumbers} />
                </div>
            </Draggable>

            {/* MODAL LAYER */}
            {showHelp && <HelpModal onClose={() => setShowHelp(false)} />}
            {showHistory && <HistoryModal logs={transactionLog} onClose={() => setShowHistory(false)} />}

            {/* NEW: RECORD / VICTORY MODAL */}
            {showRecordModal && (
                <div style={{
                    position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
                    background: 'rgba(0,0,0,0.85)', zIndex: 10001, // Higher than Buy-In
                    display: 'flex', alignItems: 'center', justifyContent: 'center'
                }}>
                    <div style={{
                        background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)',
                        padding: '3px', borderRadius: '22px', // Gradient Border Wrapper
                        boxShadow: '0 0 60px rgba(255, 215, 0, 0.6)'
                    }}>
                        <div style={{
                            background: '#111', padding: '40px', borderRadius: '20px',
                            textAlign: 'center', width: '450px'
                        }}>
                            <div style={{ fontSize: '4rem', marginBottom: '10px' }}>🏆</div>
                            <h1 style={{ color: '#FFD700', fontSize: '2.2rem', marginBottom: '15px', textTransform: 'uppercase' }}>
                                ¡Nuevo Récord!
                            </h1>
                            <p style={{ color: '#fff', fontSize: '1.2rem', marginBottom: '10px' }}>
                                Has superado tu saldo máximo histórico.
                            </p>
                            <p style={{ color: '#aaa', marginBottom: '30px' }}>
                                Saldo Actual: <span style={{ color: '#4f4', fontWeight: 'bold' }}>{formatBalance(balance)}</span>
                            </p>

                            <div style={{ display: 'flex', justifyContent: 'center', gap: '15px' }}>
                                <button
                                    onClick={() => setShowRecordModal(false)}
                                    style={{
                                        background: '#4f4', border: 'none', color: '#000', padding: '15px 30px',
                                        fontSize: '1.1rem', fontWeight: 'bold', borderRadius: '10px', cursor: 'pointer',
                                        textTransform: 'uppercase', boxShadow: '0 0 15px rgba(68, 255, 68, 0.4)'
                                    }}
                                >
                                    ¡Vamos por más!
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* 7. BUY-IN / BANKRUPTCY MODAL */}
            {showBankruptcy && !isSpinning && (
                <div style={{
                    position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
                    background: 'rgba(0,0,0,0.85)', zIndex: 10000,
                    display: 'flex', alignItems: 'center', justifyContent: 'center'
                }}>
                    <div style={{
                        background: 'linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%)',
                        padding: '40px', borderRadius: '20px', border: '2px solid #d4af37',
                        textAlign: 'center', width: '400px',
                        boxShadow: '0 0 50px rgba(212, 175, 55, 0.3)'
                    }}>
                        <h1 style={{ color: '#d4af37', fontSize: '2rem', marginBottom: '10px', textTransform: 'uppercase' }}>
                            {balance === 0 ? 'Bienvenido' : 'Saldo Insuficiente'}
                        </h1>
                        <p style={{ color: '#aaa', marginBottom: '20px' }}>
                            {balance === 0
                                ? `Por favor, ingrese el monto en ${viewCurrency} para comenzar.`
                                : `Se ha quedado sin fichas. Ingrese monto en ${viewCurrency} para recargar.`}
                        </p>

                        <div style={{ display: 'flex', justifyContent: 'center', gap: '10px', marginBottom: '20px' }}>
                            <input
                                type="number"
                                placeholder={`Monto (${viewCurrency})`}
                                value={buyInAmount}
                                onChange={(e) => setBuyInAmount(e.target.value)}
                                autoFocus
                                style={{
                                    padding: '10px', borderRadius: '5px', border: '1px solid #444',
                                    background: '#222', color: '#fff', fontSize: '1.2rem',
                                    width: '200px', textAlign: 'center' // Wider
                                }}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                        const val = parseFloat(buyInAmount)
                                        if (val >= 0) { // Allow 0 if they really want, though usually > 0
                                            const rate = RATES[viewCurrency] || 1
                                            reloadCapital(val / rate) // Convert Currency -> Units
                                            setShowBankruptcy(false)
                                            setBuyInAmount('')
                                        }
                                    }
                                }}
                            />
                        </div>

                        <button
                            onClick={() => {
                                const val = parseFloat(buyInAmount);
                                if (val >= 0) {
                                    const rate = RATES[viewCurrency] || 1
                                    reloadCapital(val / rate) // Convert Currency -> Units
                                    setShowBankruptcy(false)
                                    setBuyInAmount('')
                                } else {
                                    alert("Por favor ingrese un monto válido");
                                }
                            }}
                            style={{
                                background: 'linear-gradient(to bottom, #d4af37, #aa8c2c)',
                                border: 'none', color: '#000', padding: '12px 30px',
                                fontSize: '16px', fontWeight: 'bold', borderRadius: '50px', cursor: 'pointer',
                                boxShadow: '0 5px 15px rgba(0,0,0,0.5)',
                                transform: 'scale(1)', transition: 'transform 0.1s'
                            }}
                            onMouseEnter={e => e.target.style.transform = 'scale(1.05)'}
                            onMouseLeave={e => e.target.style.transform = 'scale(1)'}
                        >
                            INGRESAR FICHAS
                        </button>

                        {/* CLOSE / JUST WATCH BUTTON */}
                        <div style={{ marginTop: '15px' }}>
                            <button
                                onClick={() => setShowBankruptcy(false)}
                                style={{
                                    background: 'transparent', border: 'none', color: '#666',
                                    textDecoration: 'underline', cursor: 'pointer', fontSize: '0.9rem'
                                }}
                            >
                                Solo Mirar (Cerrar)
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* 6. UNIFIED BANKING HUD (VERTICAL TOWER - MASSIVE FONTS) */}
            <Draggable id="banking" isEnabled={isEditMode} initialPos={positions.banking} onDragEnd={onUpdatePos}>
                <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '12px',
                    background: 'rgba(15, 15, 15, 0.95)',
                    padding: '25px',
                    borderRadius: '20px',
                    border: '2px solid #555',
                    boxShadow: '0 10px 40px rgba(0,0,0,0.9)',
                    width: '320px', // Massive width
                    minWidth: '320px'
                }}>

                    {/* SECTION: CONTROLS & RESET */}
                    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginBottom: '10px' }}>
                        <button
                            onClick={(e) => {
                                e.stopPropagation()
                                setShowReloadModal(true)
                            }}
                            onMouseDown={(e) => e.stopPropagation()}
                            title="Recargar Fichas"
                            style={{
                                background: '#2e7d32', // Green
                                color: '#fff',
                                border: '1px solid #4caf50',
                                borderRadius: '4px',
                                fontSize: '0.8rem',
                                cursor: 'pointer',
                                padding: '5px 15px',
                                fontWeight: 'bold',
                                textTransform: 'uppercase',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '5px',
                                zIndex: 1000,
                                pointerEvents: 'auto'
                            }}
                        >
                            💲 Recargar
                        </button>
                        <button
                            onClick={(e) => {
                                e.stopPropagation()
                                setShowResetModal(true)
                            }}
                            onMouseDown={(e) => e.stopPropagation()}
                            title="Reiniciar TODO (Saldo a 0)"
                            style={{
                                background: '#3e1a1a', color: '#ff4444', border: '1px solid #ff4444', borderRadius: '4px',
                                fontSize: '0.8rem', cursor: 'pointer', padding: '5px 10px',
                                transition: 'all 0.2s', textTransform: 'uppercase',
                                fontWeight: 'bold', zIndex: 1000, pointerEvents: 'auto'
                            }}
                        >
                            ⚠ Reiniciar
                        </button>
                    </div>

                    {/* SECTION: BALANCE */}
                    <div style={{ width: '100%', borderBottom: '1px solid #444', paddingBottom: '15px' }}>
                        <div style={{
                            fontSize: '1rem', color: '#aaa', textTransform: 'uppercase', letterSpacing: '2px', fontWeight: 'bold',
                            textShadow: '0 0 10px rgba(255, 255, 255, 0.5)',
                            display: 'flex', alignItems: 'center', justifyContent: 'space-between'
                        }}>
                            <span>Saldo</span>
                            <div style={{ display: 'flex', gap: '5px' }}>
                                <button
                                    onClick={() => setShowWithdrawModal(true)}
                                    style={{
                                        background: '#333', color: '#aaa', border: '1px solid #555',
                                        borderRadius: '4px', cursor: 'pointer', fontSize: '10px', padding: '2px 5px'
                                    }}
                                    title="Retirar Fondos"
                                >
                                    RETIRAR
                                </button>
                                <button
                                    onClick={() => setShowReloadModal(true)}
                                    style={{
                                        background: '#333', color: '#aaa', border: '1px solid #555',
                                        borderRadius: '4px', cursor: 'pointer', fontSize: '10px', padding: '2px 5px'
                                    }}
                                    title="Recargar Fondos"
                                >
                                    +
                                </button>
                            </div>
                        </div>
                        <div style={{ fontSize: '2.4rem', color: '#ffd700', fontWeight: 'bold', textAlign: 'right', lineHeight: '1', fontFamily: 'Roboto Mono, monospace' }}>
                            {formatBalance(balance)}
                        </div>
                    </div>

                    {/* SECTION: POTENTIAL BEST PAYOUT */}
                    <div style={{ width: '100%', borderBottom: '1px solid #444', paddingBottom: '15px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2px' }}>
                            <div style={{ fontSize: '0.8rem', color: '#aaa', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: '1px' }}>
                                Mejor Pago
                            </div>
                            <div style={{ fontSize: '0.8rem', color: '#ffcc00', fontWeight: 'bold' }}>
                                {bestPayout.numbers.length > 0 ? (bestPayout.numbers.length > 5 ? 'Varios...' : bestPayout.numbers.join(', ')) : '-'}
                            </div>
                        </div>
                        <div style={{
                            fontSize: '1.4rem',
                            color: bestPayout.amount > 0 ? '#ffcc00' : '#444',
                            textAlign: 'right',
                            fontFamily: 'Roboto Mono, monospace',
                            lineHeight: '1',
                            textShadow: bestPayout.amount > 0 ? '0 0 10px rgba(255, 204, 0, 0.3)' : 'none'
                        }}>
                            {formatValue(bestPayout.amount)}
                        </div>
                    </div>

                    {/* SECTION: POTENTIAL MAX BALANCE */}
                    {bestPayout.amount > 0 && (
                        <div style={{ width: '100%', borderBottom: '1px solid #444', paddingBottom: '15px' }}>
                            <div style={{ fontSize: '0.8rem', color: '#aaa', textTransform: 'uppercase', marginBottom: '2px', fontWeight: 'bold', letterSpacing: '1px' }}>
                                Saldo Potencial
                            </div>
                            <div style={{
                                fontSize: '1.4rem',
                                color: '#00d4ff',
                                textAlign: 'right',
                                lineHeight: '1',
                                fontFamily: 'Roboto Mono, monospace',
                                textShadow: '0 0 10px rgba(0, 212, 255, 0.4)'
                            }}>
                                {formatBalance(balance + bestPayout.amount)}
                            </div>
                        </div>
                    )}

                    {/* SECTION: MAX BALANCE */}
                    <div style={{ width: '100%', borderBottom: '1px solid #444', paddingBottom: '15px' }}>
                        <div style={{ fontSize: '0.8rem', color: '#888', textTransform: 'uppercase', marginBottom: '2px', fontWeight: 'bold', letterSpacing: '1px' }}>Saldo Máximo</div>
                        <div style={{
                            fontSize: '1.4rem',
                            color: isNewRecord ? '#fff' : '#d4af37',
                            textAlign: 'right',
                            lineHeight: '1',
                            fontFamily: 'Roboto Mono, monospace',
                            opacity: isNewRecord ? 1 : 0.8,
                            textShadow: isNewRecord ? '0 0 15px gold, 0 0 30px white' : 'none',
                            transition: 'all 0.3s ease'
                        }}>
                            {formatBalance(maxBalance)} {isNewRecord && '🏆'}
                        </div>
                    </div>

                    {/* SECTION: INITIAL BALANCE */}
                    <div style={{ width: '100%', borderBottom: '1px solid #444', paddingBottom: '15px' }}>
                        <div style={{ fontSize: '0.8rem', color: '#888', textTransform: 'uppercase', marginBottom: '2px', fontWeight: 'bold', letterSpacing: '1px' }}>Saldo Inicial</div>
                        <div style={{ fontSize: '1.4rem', color: '#888', textAlign: 'right', lineHeight: '1', fontFamily: 'Roboto Mono, monospace' }}>
                            {formatValue(initialCapital)}
                        </div>
                    </div>

                    {/* SECTION: RECORD PROFIT */}
                    <div style={{ width: '100%', borderBottom: '1px solid #444', paddingBottom: '15px' }}>
                        <div style={{ fontSize: '0.8rem', color: '#888', textTransform: 'uppercase', marginBottom: '2px', fontWeight: 'bold', letterSpacing: '1px' }}>
                            Ganancia Récord
                        </div>
                        <div style={{
                            fontSize: '1.4rem',
                            color: (maxBalance - initialCapital) > 0 ? '#4f4' : '#888',
                            textAlign: 'right',
                            lineHeight: '1',
                            fontFamily: 'Roboto Mono, monospace'
                        }}>
                            {formatValue(maxBalance - initialCapital)}
                        </div>
                    </div>

                    {/* SECTION: RECORD PROFIT PER MINUTE */}
                    {(maxBalance - initialCapital) > 0 && (
                        <div style={{ width: '100%', borderBottom: '1px solid #444', paddingBottom: '15px' }}>
                            <div style={{ fontSize: '0.8rem', color: '#888', textTransform: 'uppercase', marginBottom: '2px', fontWeight: 'bold', letterSpacing: '1px' }}>
                                Ganancia Récord / Min
                            </div>
                            <div style={{
                                fontSize: '1.4rem',
                                color: '#4f4',
                                textAlign: 'right',
                                lineHeight: '1',
                                fontFamily: 'Roboto Mono, monospace'
                            }}>
                                {(() => {
                                    const mins = Math.max(0.1, (now - sessionStart) / 60000)
                                    const profit = maxBalance - initialCapital
                                    return formatValue(profit / mins)
                                })()}
                            </div>
                        </div>
                    )}

                    {/* SECTION: BET */}
                    <div style={{ width: '100%', borderBottom: '1px solid #444', paddingBottom: '15px' }}>
                        <div style={{ fontSize: '1rem', color: '#aaa', textTransform: 'uppercase', marginBottom: '5px', fontWeight: 'bold', letterSpacing: '1px' }}>Apuesta</div>
                        <div style={{ fontSize: '2.4rem', color: '#fff', textAlign: 'right', lineHeight: '1', fontFamily: 'Roboto Mono, monospace' }}>
                            {formatValue(currentRoundBet)}
                        </div>
                    </div>

                    {/* SECTION: COVERAGE */}
                    <div style={{ width: '100%', borderBottom: '1px solid #444', paddingBottom: '15px' }}>
                        <div style={{ fontSize: '0.8rem', color: '#888', textTransform: 'uppercase', marginBottom: '2px', fontWeight: 'bold', letterSpacing: '1px' }}>Cobertura</div>
                        <div style={{ fontSize: '1.4rem', color: '#00d4ff', textAlign: 'right', lineHeight: '1', fontFamily: 'Roboto Mono, monospace', opacity: 0.9 }}>
                            {calculateCoverage(currentBets).toFixed(1)}%
                        </div>
                    </div>

                    {/* SECTION: WIN */}
                    <div style={{ width: '100%', borderBottom: '1px solid #444', paddingBottom: '15px' }}>
                        <div style={{ fontSize: '1rem', color: '#aaa', textTransform: 'uppercase', marginBottom: '0px', fontWeight: 'bold', letterSpacing: '1px' }}>Ganancia</div>
                        <div style={{
                            fontSize: '3.5rem',
                            color: lastWinAmount > 0 ? '#4f4' : '#555',
                            fontWeight: 'bold',
                            textAlign: 'right',
                            lineHeight: '1.1',
                            fontFamily: 'Roboto Mono, monospace',
                            textShadow: lastWinAmount > 0 ? '0 0 25px rgba(68, 255, 68, 0.8)' : 'none'
                        }}>
                            {formatValue(lastWinAmount)}
                        </div>
                    </div>

                    {/* CURRENCY SELECTOR */}
                    <div style={{ display: 'flex', gap: '5px', marginTop: '10px', background: '#111', padding: '5px', borderRadius: '8px' }}>
                        {['COL', 'USA', 'EUR'].map(curr => (
                            <button key={curr} onClick={() => setViewCurrency(curr)}
                                style={{
                                    flex: 1,
                                    background: viewCurrency === curr ? '#d4af37' : 'transparent',
                                    color: viewCurrency === curr ? '#000' : '#666',
                                    border: 'none',
                                    padding: '8px 0',
                                    cursor: 'pointer',
                                    fontWeight: 'bold',
                                    fontSize: '0.9rem',
                                    borderRadius: '6px'
                                }}
                            >
                                {curr}
                            </button>
                        ))}
                    </div>
                </div>
            </Draggable>

            {/* HOVER POTENTIAL WIN TOOLTIP */}
            {potentialWin > 0 && (
                <div style={{
                    position: 'fixed',
                    top: positions.board.y - 40,
                    left: positions.board.x + 300,
                    background: 'rgba(255, 215, 0, 0.9)',
                    color: 'black',
                    padding: '8px 15px',
                    borderRadius: '20px',
                    fontWeight: 'bold',
                    zIndex: 10000,
                    pointerEvents: 'none',
                    border: '2px solid white',
                    boxShadow: '0 0 15px #d4af37'
                }}>
                    Pago Potencial: {formatValue(potentialWin)}
                </div>
            )}

            {/* NEW: CONTROLS HUD */}
            <Draggable id="controls" isEnabled={isEditMode} initialPos={positions.controls} onDragEnd={onUpdatePos}>
                <div style={{
                    display: 'flex', gap: '10px', background: 'rgba(0,0,0,0.6)', padding: '10px', borderRadius: '50px',
                    border: '1px solid #555', alignItems: 'center'
                }}>
                    <button className="spin-btn" onClick={handleSpin} disabled={isSpinning}
                        style={{
                            padding: '15px 30px', borderRadius: '30px', border: 'none',
                            background: isSpinning ? '#444' : 'linear-gradient(145deg, #ffd700, #b8860b)',
                            color: isSpinning ? '#888' : '#000',
                            fontWeight: 'bold', fontSize: '1.2rem', cursor: isSpinning ? 'not-allowed' : 'pointer',
                            boxShadow: '0 4px 15px rgba(255, 215, 0, 0.3)', marginRight: '10px'
                        }}
                    >
                        {isSpinning ? "..." : "GIRAR"}
                    </button>
                    <button onClick={handleRepeat} disabled={Object.keys(lastBets).length === 0}
                        style={{ padding: '10px 15px', borderRadius: '20px', border: 'none', background: '#336699', color: 'white', fontWeight: 'bold', cursor: 'pointer', opacity: Object.keys(lastBets).length === 0 ? 0.5 : 1 }}>
                        REPETIR
                    </button>
                    <button onClick={handleDouble} disabled={Object.keys(currentBets).length === 0}
                        style={{ padding: '10px 15px', borderRadius: '20px', border: 'none', background: '#336699', color: 'white', fontWeight: 'bold', cursor: 'pointer', opacity: Object.keys(currentBets).length === 0 ? 0.5 : 1 }}>
                        x2
                    </button>
                    <button onClick={handleUndo} disabled={betHistory.length === 0}
                        style={{ padding: '10px 15px', borderRadius: '20px', border: 'none', background: '#663333', color: 'white', fontWeight: 'bold', cursor: 'pointer', opacity: betHistory.length === 0 ? 0.5 : 1 }}>
                        DESHACER
                    </button>
                    <button onClick={handleClear} disabled={Object.keys(currentBets).length === 0}
                        style={{ padding: '10px 15px', borderRadius: '20px', border: 'none', background: '#993333', color: 'white', fontWeight: 'bold', cursor: 'pointer', opacity: Object.keys(currentBets).length === 0 ? 0.5 : 1 }}>
                        LIMPIAR
                    </button>
                </div>
            </Draggable>

            {/* AUTOPLAY HUD */}
            <Draggable id="autoplay" isEnabled={isEditMode} initialPos={positions.autoplay} onDragEnd={onUpdatePos}>
                <div style={{
                    display: 'flex', gap: '5px', background: 'rgba(0,0,0,0.6)', padding: '8px', borderRadius: '30px',
                    border: '1px solid #555', alignItems: 'center'
                }}>
                    <div style={{ color: '#aaa', fontSize: '10px', marginLeft: '5px', fontWeight: 'bold' }}>AUTO ({autoPlayCount}):</div>
                    {autoPlayCount > 0 ? (
                        <button onClick={() => setAutoPlayCount(0)}
                            style={{
                                background: '#f44', color: 'white', border: 'none', padding: '5px 15px',
                                borderRadius: '15px', cursor: 'pointer', fontWeight: 'bold', fontSize: '12px'
                            }}
                        >
                            DETENER
                        </button>
                    ) : (
                        [10, 25, 50, 100].map(count => (
                            <button key={count} onClick={() => setAutoPlayCount(count)}
                                style={{
                                    background: 'transparent', color: '#fff', border: '1px solid #777',
                                    padding: '5px 10px', borderRadius: '15px', cursor: 'pointer', fontSize: '11px',
                                    transition: 'all 0.2s'
                                }}
                                onMouseEnter={e => { e.target.style.background = '#d4af37'; e.target.style.color = 'black' }}
                                onMouseLeave={e => { e.target.style.background = 'transparent'; e.target.style.color = '#fff' }}
                            >
                                {count}
                            </button>
                        ))
                    )}
                </div>
            </Draggable>

            {/* 7. CHIPS HUD (Separated) */}
            <Draggable id="chips" isEnabled={isEditMode} initialPos={positions.chips} onDragEnd={onUpdatePos}>
                <div className="ui-overlay-loose" style={{
                    background: 'rgba(0,0,0,0.5)', padding: '10px', borderRadius: '10px'
                }}>
                    <div className="chip-selector">
                        {[1, 2, 5, 10, 20, 50, 100, 200, 500, 1000].map(val => (
                            <div key={val} className={`chip-btn chip-${val} ${selectedChip === val ? 'selected' : ''}`}
                                onClick={() => setSelectedChip(val)}
                            >
                                {formatValue(val)}
                            </div>
                        ))}
                    </div>
                </div>
            </Draggable>

            {/* Top Opportunity Widget - Floating */}
            <Draggable id="opportunity" isEnabled={isEditMode} initialPos={positions.opportunity} onDragEnd={onUpdatePos}>
                <TopOpportunityWidget />
            </Draggable>

            {/* History Panel - Floating */}
            <Draggable id="history" isEnabled={isEditMode} initialPos={positions.history} onDragEnd={onUpdatePos}>
                <HistoryPanel />
            </Draggable>

            {/* Projections Panel - Floating */}
            <Draggable id="projections" isEnabled={isEditMode} initialPos={positions.projections} onDragEnd={onUpdatePos}
                style={{ zIndex: 4000 }}
            >
                <ProjectionsPanel viewCurrency={viewCurrency} currentBets={currentBets} />
            </Draggable>

            {/* RELOAD MODAL */}
            {showReloadModal && (
                <div style={{
                    position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
                    background: 'rgba(0,0,0,0.9)', zIndex: 999999,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    backdropFilter: 'blur(8px)'
                }}>
                    <div style={{
                        background: 'linear-gradient(145deg, #1a1a1a, #0d0d0d)',
                        border: '1px solid #333',
                        padding: '40px',
                        borderRadius: '20px',
                        textAlign: 'center',
                        boxShadow: '0 0 50px rgba(0,0,0,0.8)',
                        maxWidth: '450px',
                        width: '90%'
                    }}>
                        <h2 style={{ color: '#d4af37', fontSize: '1.8rem', marginBottom: '10px', textTransform: 'uppercase' }}>Recargar Fondos</h2>
                        <p style={{ color: '#aaa', marginBottom: '20px', fontSize: '1rem', lineHeight: '1.5' }}>
                            Ingresa la cantidad de fichas que deseas añadir a tu saldo actual.
                        </p>

                        <div style={{ marginBottom: '30px', position: 'relative' }}>
                            <span style={{ position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)', color: '#666', fontSize: '1.2rem' }}>$</span>
                            <input
                                type="number"
                                value={reloadAmount}
                                onChange={(e) => setReloadAmount(e.target.value)}
                                style={{
                                    width: '100%',
                                    padding: '15px 15px 15px 35px',
                                    background: '#000',
                                    border: '1px solid #444',
                                    borderRadius: '10px',
                                    color: '#fff',
                                    fontSize: '1.5rem',
                                    fontWeight: 'bold',
                                    textAlign: 'center',
                                    outline: 'none',
                                    fontFamily: 'Roboto Mono, monospace'
                                }}
                            />
                        </div>

                        <div style={{ display: 'flex', gap: '20px', justifyContent: 'center' }}>
                            <button
                                onClick={() => setShowReloadModal(false)}
                                style={{
                                    padding: '15px 30px',
                                    borderRadius: '50px',
                                    border: '1px solid #444',
                                    background: 'transparent',
                                    color: '#888',
                                    cursor: 'pointer',
                                    fontWeight: 'bold',
                                    fontSize: '0.9rem',
                                    transition: 'all 0.2s'
                                }}
                            >
                                CANCELAR
                            </button>
                            <button
                                onClick={() => {
                                    const amountVal = Number(reloadAmount)
                                    if (amountVal > 0) {
                                        const rate = RATES[viewCurrency] || 1
                                        reloadCapital(amountVal / rate)
                                        setShowReloadModal(false)
                                        addToast(`¡Recarga Exitosa! +${formatValue(amountVal / rate)}`, "success")
                                        soundManager.playChip()
                                    } else {
                                        addToast("Ingresa un monto válido", "error")
                                    }
                                }}
                                style={{
                                    padding: '15px 40px',
                                    borderRadius: '50px',
                                    border: 'none',
                                    background: 'linear-gradient(145deg, #2e7d32, #1b5e20)', // Green theme for reload
                                    color: '#fff',
                                    cursor: 'pointer',
                                    fontWeight: 'bold',
                                    fontSize: '1.1rem',
                                    boxShadow: '0 4px 15px rgba(46, 125, 50, 0.4)',
                                    transform: 'scale(1.05)',
                                    textTransform: 'uppercase'
                                }}
                            >
                                RECARGAR
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* WITHDRAW MODAL */}
            {showWithdrawModal && (
                <div style={{
                    position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
                    background: 'rgba(0,0,0,0.9)', zIndex: 999999,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    backdropFilter: 'blur(8px)'
                }}>
                    <div style={{
                        background: 'linear-gradient(145deg, #1a1a1a, #0d0d0d)',
                        border: '1px solid #333',
                        padding: '40px',
                        borderRadius: '20px',
                        textAlign: 'center',
                        boxShadow: '0 0 50px rgba(0,0,0,0.8)',
                        maxWidth: '450px',
                        width: '90%'
                    }}>
                        <h2 style={{ color: '#aaa', fontSize: '1.8rem', marginBottom: '10px', textTransform: 'uppercase' }}>Retirar Fondos</h2>
                        <p style={{ color: '#666', marginBottom: '20px', fontSize: '1rem', lineHeight: '1.5' }}>
                            Ingresa la cantidad que deseas retirar de tu saldo.
                        </p>

                        <div style={{ marginBottom: '30px', position: 'relative' }}>
                            <span style={{ position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)', color: '#666', fontSize: '1.2rem' }}>$</span>
                            <input
                                type="number"
                                value={withdrawAmount}
                                onChange={(e) => setWithdrawAmount(e.target.value)}
                                onKeyDown={(e) => e.key === 'Enter' && handleWithdrawSubmit()}
                                placeholder="0"
                                autoFocus
                                style={{
                                    width: '100%',
                                    padding: '15px 15px 15px 35px',
                                    background: '#000',
                                    border: '1px solid #444',
                                    borderRadius: '10px',
                                    color: '#fff',
                                    fontSize: '1.5rem',
                                    fontWeight: 'bold',
                                    textAlign: 'center',
                                    outline: 'none',
                                    fontFamily: 'Roboto Mono, monospace'
                                }}
                            />
                        </div>

                        <div style={{ display: 'flex', gap: '20px', justifyContent: 'center' }}>
                            <button
                                onClick={() => setShowWithdrawModal(false)}
                                style={{
                                    padding: '15px 30px',
                                    borderRadius: '50px',
                                    border: '1px solid #444',
                                    background: 'transparent',
                                    color: '#888',
                                    cursor: 'pointer',
                                    fontWeight: 'bold',
                                    fontSize: '0.9rem',
                                    transition: 'all 0.2s'
                                }}
                            >
                                CANCELAR
                            </button>
                            <button
                                onClick={handleWithdrawSubmit}
                                style={{
                                    padding: '15px 40px',
                                    borderRadius: '50px',
                                    border: 'none',
                                    background: 'linear-gradient(145deg, #d32f2f, #b71c1c)', // Red theme for withdraw
                                    color: '#fff',
                                    cursor: 'pointer',
                                    fontWeight: 'bold',
                                    fontSize: '1.1rem',
                                    boxShadow: '0 4px 15px rgba(211, 47, 47, 0.4)',
                                    transform: 'scale(1.05)',
                                    textTransform: 'uppercase'
                                }}
                            >
                                RETIRAR
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* RESET MODAL */}
            {showResetModal && (
                <div style={{
                    position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
                    background: 'rgba(0,0,0,0.95)', zIndex: 999999,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    backdropFilter: 'blur(10px)'
                }}>
                    <div style={{
                        background: 'linear-gradient(145deg, #2a0a0a, #1a0505)',
                        border: '2px solid #ff4444',
                        padding: '40px',
                        borderRadius: '20px',
                        textAlign: 'center',
                        boxShadow: '0 0 60px rgba(255, 68, 68, 0.4)',
                        maxWidth: '500px',
                        width: '90%'
                    }}>
                        <div style={{ fontSize: '4rem', marginBottom: '20px' }}>⚠️</div>
                        <h2 style={{ color: '#ff4444', fontSize: '2rem', marginBottom: '20px', textTransform: 'uppercase', letterSpacing: '2px' }}>
                            ¿Reinicio Completo?
                        </h2>
                        <div style={{ color: '#fff', marginBottom: '30px', fontSize: '1.1rem', lineHeight: '1.6', textAlign: 'left', background: 'rgba(0,0,0,0.5)', padding: '15px', borderRadius: '10px' }}>
                            <ul style={{ margin: 0, paddingLeft: '20px' }}>
                                <li>Tu saldo volverá a <b>$0</b>.</li>
                                <li>Se borrará todo el historial de jugadas.</li>
                                <li>Se eliminará el récord de saldo máximo.</li>
                            </ul>
                        </div>

                        <div style={{ display: 'flex', gap: '20px', justifyContent: 'center' }}>
                            <button
                                onClick={() => setShowResetModal(false)}
                                style={{
                                    padding: '15px 30px',
                                    borderRadius: '50px',
                                    border: '1px solid #666',
                                    background: 'transparent',
                                    color: '#aaa',
                                    cursor: 'pointer',
                                    fontWeight: 'bold',
                                    fontSize: '1rem',
                                    transition: 'all 0.2s',
                                    flex: 1
                                }}
                            >
                                CANCELAR
                            </button>
                            <button
                                onClick={() => {
                                    hardReset()
                                    setMaxBalance(0)
                                    setShowResetModal(false)
                                    addToast("Sistema Reiniciado Correctamente", "success")
                                    soundManager.playChip()
                                }}
                                style={{
                                    padding: '15px 30px',
                                    borderRadius: '50px',
                                    border: 'none',
                                    background: 'linear-gradient(145deg, #d32f2f, #b71c1c)',
                                    color: '#fff',
                                    cursor: 'pointer',
                                    fontWeight: 'bold',
                                    fontSize: '1rem',
                                    boxShadow: '0 4px 20px rgba(211, 47, 47, 0.5)',
                                    transform: 'scale(1.05)',
                                    textTransform: 'uppercase',
                                    flex: 1
                                }}
                            >
                                SÍ, BORRAR TODO
                            </button>
                        </div>
                    </div>
                </div>
            )}

        </div>
    )
}
