import React, { useState, useEffect } from 'react';
import { useFinancialStore } from '../logic/FinancialSimulator';

export const SessionClock = () => {
    // Access store directly
    const sessionStart = useFinancialStore(state => state.sessionStart);

    // Local state for display
    const [currentTime, setCurrentTime] = useState(new Date());
    const [duration, setDuration] = useState('00:00:00');

    useEffect(() => {
        const timer = setInterval(() => {
            const now = new Date();
            setCurrentTime(now);

            // Calculate duration based on sessionStart
            const start = sessionStart || Date.now(); // Fallback to prevent NaN
            const diff = now.getTime() - start;

            // Format duration
            const hours = Math.floor(diff / 3600000);
            const minutes = Math.floor((diff % 3600000) / 60000);
            const seconds = Math.floor((diff % 60000) / 1000);

            const hh = hours.toString().padStart(2, '0');
            const mm = minutes.toString().padStart(2, '0');
            const ss = seconds.toString().padStart(2, '0');
            setDuration(`${hh}:${mm}:${ss}`);
        }, 1000);

        return () => clearInterval(timer);
    }, [sessionStart]);

    // Formatters
    const formatDate = (date) => {
        return date.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
    };

    const formatTime = (date) => {
        return date.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    };

    return (
        <div style={{
            display: 'flex', flexDirection: 'column',
            background: 'rgba(0,0,0,0.85)', padding: '15px 20px', borderRadius: '12px',
            border: '2px solid #555', color: '#eee',
            fontFamily: 'Roboto Mono, monospace', fontSize: '1rem',
            minWidth: '220px', textAlign: 'right',
            pointerEvents: 'auto', // Re-enable pointer events for possible interactions
            boxShadow: '0 4px 15px rgba(0,0,0,0.5)'
        }}>
            <div style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '2.2rem', marginBottom: '5px', lineHeight: '1' }}>
                {formatTime(currentTime)}
            </div>
            <div style={{ fontSize: '1rem', color: '#aaa', textTransform: 'capitalize', marginBottom: '10px' }}>
                {formatDate(currentTime)}
            </div>

            <div style={{ borderTop: '1px solid #444', paddingTop: '10px', display: 'flex', justifyContent: 'space-between', color: '#888', fontSize: '0.9rem', fontWeight: 'bold' }}>
                <span>SESIÓN:</span>
                <span style={{ color: '#fff', fontSize: '1.2rem' }}>{duration}</span>
            </div>
        </div>
    );
};
