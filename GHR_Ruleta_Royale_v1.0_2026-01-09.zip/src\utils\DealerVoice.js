export class DealerVoice {
    constructor() {
        this.synth = window.speechSynthesis
        this.voice = null
        this.enabled = true
        this.init()
    }

    init() {
        if (!this.synth) {
            console.warn("Speech Synthesis not supported")
            this.enabled = false
            return
        }
        // Wait for voices to load
        if (this.synth.onvoiceschanged !== undefined) {
            this.synth.onvoiceschanged = () => this.setVoice()
        }
        this.setVoice()
    }

    setVoice() {
        const voices = this.synth.getVoices()
        // Priority: Google Español -> Microsoft Spanish -> Any ES-ES -> Any ES
        this.voice = voices.find(v => v.lang === 'es-ES' && v.name.includes('Google'))
            || voices.find(v => v.name.includes('Microsoft') && v.lang.includes('es'))
            || voices.find(v => v.lang === 'es-ES')
            || voices.find(v => v.lang.includes('es'))
            || null

        console.log("Dealer Voice Selected:", this.voice ? this.voice.name : "Default")
    }

    speak(text, priority = false) {
        if (!this.enabled) return
        if (priority) this.synth.cancel() // Stop current if priority

        const utterance = new SpeechSynthesisUtterance(text)
        if (this.voice) utterance.voice = this.voice

        // Tweaked for maximum clarity
        utterance.rate = 1.0 // Normal speed (was 1.1)
        utterance.pitch = 1.0 // Natural pitch
        utterance.volume = 1.0

        this.synth.speak(utterance)
    }

    sayRandom(phrases, priority = false) {
        const text = phrases[Math.floor(Math.random() * phrases.length)]
        this.speak(text, priority)
    }

    // --- GAME EVENTS ---

    welcome() {
        this.sayRandom([
            "Bienvenidos. Hagan sus apuestas por favor.",
            "La mesa está abierta. Buena suerte.",
            "Iniciamos nueva ronda. Hagan juego."
        ])
    }

    betsOpen() {
        this.sayRandom([
            "Hagan sus apuestas.",
            "Apuestas abiertas.",
            "Es el momento de apostar.",
            "Decidan su suerte, señores."
        ])
    }

    betsClosing() {
        this.sayRandom([
            "Cerramos apuestas.",
            "Últimos segundos.",
            "Casi no hay más tiempo.",
            "Se cierran las apuestas."
        ], true)
    }

    noMoreBets() {
        this.sayRandom([
            "¡No va más!",
            "¡No se admiten más apuestas!",
            "¡Suerte! No va más.",
            "Juego cerrado."
        ], true)
    }

    winner(number, color) {
        // Clear, standardized announcements
        const bases = [
            `El ganador es el ${number}, ${color}.`,
            `Número ${number}, color ${color}.`,
            `${number}, ${color}. ¡Felicidades!`
        ]
        const text = bases[Math.floor(Math.random() * bases.length)]
        this.speak(text, true)
    }
    profitWin() {
        this.sayRandom([
            "¡Excelente ganancia!",
            "Has superado tu apuesta.",
            "¡Buena jugada! Ganancia limpia.",
            "Victoria rentable.",
            "Así se hace, superando la casa."
        ], true)
    }
}

export const dealer = new DealerVoice()
