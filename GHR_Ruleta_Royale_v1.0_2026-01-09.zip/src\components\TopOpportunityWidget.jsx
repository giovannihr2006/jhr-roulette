import React, { useMemo } from 'react';
import { useFinancialStore } from '../logic/FinancialSimulator';
import { ALL_SPLITS, ALL_STREETS, ALL_CORNERS, ALL_LINES } from '../logic/RouletteUtils'
// import { Draggable } from './Draggable';

const EMPTY_ARRAY = [];

export const TopOpportunityWidget = () => {
    const history = useFinancialStore(state => state.numberHistory || EMPTY_ARRAY);
    const baseWaitThreshold = useFinancialStore(state => state.baseWaitThreshold || 300);

    // SAFETY CHECK: Force return null to check if crash persists
    // return null

    const topOpportunity = useMemo(() => {
        try {
            if (!history || history.length === 0) return null
            if (!ALL_SPLITS || !ALL_STREETS) {
                console.warn("DEBUG: RouletteUtils not loaded yet")
                return null
            }

            const countMisses = (numbers) => {
                let misses = 0
                for (let i = history.length - 1; i >= 0; i--) {
                    if (numbers.includes(history[i])) return misses
                    misses++
                }
                return misses
            }

            const allOps = []

            // 1. Plenos (Straight Up)
            const tPleno = baseWaitThreshold
            for (let i = 0; i <= 36; i++) {
                const m = countMisses([i])
                allOps.push({ type: 'Pleno', name: i.toString(), misses: m, limit: tPleno, ratio: m / tPleno, nums: [i] })
            }

            // 2. Medios (Splits)
            const tMedio = Math.round(baseWaitThreshold / 2)
            ALL_SPLITS.forEach(bet => {
                const m = countMisses(bet.numbers)
                allOps.push({ type: 'Medio', name: bet.name.replace('Medio ', ''), misses: m, limit: tMedio, ratio: m / tMedio, nums: bet.numbers })
            })

            // 3. Calles (Streets)
            const tCalle = Math.round(baseWaitThreshold / 3)
            ALL_STREETS.forEach(bet => {
                const m = countMisses(bet.numbers)
                allOps.push({ type: 'Calle', name: bet.name.replace('Calle ', ''), misses: m, limit: tCalle, ratio: m / tCalle, nums: bet.numbers })
            })

            // 4. Seisenas (Lines)
            const tLine = Math.round(baseWaitThreshold / 6)
            ALL_LINES.forEach(bet => {
                const m = countMisses(bet.numbers)
                allOps.push({ type: 'Seisena', name: bet.name.replace('Seisena ', ''), misses: m, limit: tLine, ratio: m / tLine, nums: bet.numbers })
            })

            // 5. Cuadros (Corners)
            const tCorner = Math.round(baseWaitThreshold / 4)
            ALL_CORNERS.forEach(bet => {
                const m = countMisses(bet.numbers)
                allOps.push({ type: 'Cuadro', name: bet.name.replace('Cuadro ', ''), misses: m, limit: tCorner, ratio: m / tCorner, nums: bet.numbers })
            })

            // Sort by Ratio DESC and take top 1
            const sorted = allOps.sort((a, b) => b.ratio - a.ratio)
            return sorted.length > 0 ? sorted[0] : null

        } catch (err) {
            console.error("CRITICAL ERROR in TopOpportunityWidget:", err)
            return null
        }
    }, [history, baseWaitThreshold])

    // Always render, even if no opportunity, so user can see the widget
    const content = topOpportunity ? (
        <>
            <div style={{
                fontSize: '0.9rem', color: '#ffd700', fontWeight: 'bold',
                textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '8px'
            }}>
                🏆 Mejor Oportunidad
            </div>

            <div style={{
                fontSize: '1.8rem', fontWeight: '900', color: '#fff',
                textShadow: '0 0 10px rgba(255, 215, 0, 0.6)'
            }}>
                {topOpportunity.type} {topOpportunity.type === 'Pleno' ? '#' : ''}{topOpportunity.name}
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginTop: '5px' }}>
                <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '0.7rem', color: '#aaa' }}>ESPERA</div>
                    <div style={{ fontWeight: 'bold' }}>
                        {topOpportunity.misses} / <span style={{ color: '#888' }}>{topOpportunity.limit}</span>
                    </div>
                </div>

                <div style={{
                    background: '#ffd700', color: '#000', padding: '2px 8px',
                    borderRadius: '4px', fontWeight: 'bold', fontSize: '1.1rem'
                }}>
                    {(topOpportunity.ratio * 100).toFixed(0)}%
                </div>
            </div>
        </>
    ) : (
        <>
            <div style={{
                fontSize: '0.9rem', color: '#666', fontWeight: 'bold',
                textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '8px'
            }}>
                🏆 Mejor Oportunidad
            </div>
            <div style={{ color: '#888', fontSize: '0.9rem', fontStyle: 'italic' }}>
                Analizando historial...
            </div>
        </>
    );

    return (
        <div style={{
            background: 'linear-gradient(135deg, rgba(20, 20, 20, 0.95) 0%, rgba(40, 40, 40, 0.95) 100%)',
            padding: '15px 25px', borderRadius: '12px',
            color: '#eee',
            fontFamily: 'Roboto, sans-serif',
            boxShadow: '0 0 20px rgba(255, 215, 0, 0.3), 0 0 10px rgba(0,0,0,0.5)',
            border: '2px solid #ffd700',
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            minWidth: '200px',
            animation: 'pulse 2s infinite',
            position: 'relative', zIndex: 9999
        }}>
            {content}

            <style>{`
                @keyframes pulse {
                    0% { box-shadow: 0 0 15px rgba(255, 215, 0, 0.2); }
                    50% { box-shadow: 0 0 25px rgba(255, 215, 0, 0.5); }
                    100% { box-shadow: 0 0 15px rgba(255, 215, 0, 0.2); }
                }
            `}</style>
        </div>
    );
};
