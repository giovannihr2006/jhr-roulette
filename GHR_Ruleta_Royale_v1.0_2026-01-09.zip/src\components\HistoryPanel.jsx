import React, { useMemo } from 'react';
import { useFinancialStore } from '../logic/FinancialSimulator';

const REDS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
const EMPTY_ARRAY = [];

const NumberBadge = ({ number, size = 30 }) => {
    let bg = '#111'; // Black
    if (number === 0) bg = '#28a745'; // Green
    else if (REDS.includes(number)) bg = '#dc3545'; // Red

    return (
        <div style={{
            width: `${size}px`, height: `${size}px`, borderRadius: '50%',
            backgroundColor: bg, color: 'white',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 'bold', fontSize: `${size * 0.5}px`,
            border: '2px solid #fff', margin: '2px'
        }}>
            {number}
        </div>
    );
};

export const HistoryPanel = () => {
    const history = useFinancialStore(state => state.numberHistory || EMPTY_ARRAY);

    // Derived Stats (Hot/Cold)
    const { hotNumbers, coldNumbers, last20 } = useMemo(() => {
        try {
            const counts = {};
            const recent = history.slice(-20).reverse(); // Last 20, newest first

            // Count all history
            history.forEach(n => {
                counts[n] = (counts[n] || 0) + 1;
            });

            const entries = [];
            for (let i = 0; i <= 36; i++) {
                entries.push({ num: i, count: counts[i] || 0 });
            }

            const hot = [...entries].sort((a, b) => b.count - a.count).slice(0, 5);
            const cold = [...entries].sort((a, b) => a.count - b.count).slice(0, 5);

            return { hotNumbers: hot, coldNumbers: cold, last20: recent };
        } catch (e) {
            console.error("History Calc Error", e)
            return { hotNumbers: [], coldNumbers: [], last20: [] }
        }
    }, [history]);

    if (!history) return null

    return (
        <div style={{
            background: 'rgba(20, 20, 20, 0.95)',
            padding: '15px', borderRadius: '15px',
            color: '#eee', width: '300px',
            fontFamily: 'Roboto, sans-serif',
            boxShadow: '0 10px 30px rgba(0,0,0,0.8)',
            border: '1px solid #444',
            maxHeight: '80vh', overflowY: 'auto'
        }}>
            {/* HEADER */}
            <div style={{ textAlign: 'center', marginBottom: '15px', borderBottom: '1px solid #444', paddingBottom: '10px' }}>
                <h3 style={{ margin: 0, color: '#4dabf7', textTransform: 'uppercase', fontSize: '1rem' }}>Historial & Tendencias</h3>
            </div>

            {/* LAST 20 */}
            <div style={{ marginBottom: '15px' }}>
                <div style={{ fontSize: '0.8rem', color: '#aaa', marginBottom: '5px' }}>ÚLTIMOS 20</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', alignItems: 'center' }}>
                    {last20.length === 0 ? <div style={{ color: '#666', fontStyle: 'italic', fontSize: '0.8rem' }}>Sin historial...</div> : null}
                    {last20.map((num, i) => (
                        <div key={i} style={i === 0 ? { border: '2px solid gold', borderRadius: '50%', padding: '2px', boxShadow: '0 0 10px gold' } : {}}>
                            <NumberBadge number={num} size={i === 0 ? 44 : 26} />
                        </div>
                    ))}
                </div>
            </div>

            {/* HOT & COLD */}
            <div style={{ marginBottom: '15px' }}>
                <div style={{ fontSize: '0.8rem', color: '#ff6b6b', marginBottom: '5px', display: 'flex', alignItems: 'center', gap: '5px' }}>
                    🔥 CALIENTES
                </div>
                <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                    {hotNumbers.map((item, i) => (
                        <NumberBadge key={i} number={item.num} size={28} />
                    ))}
                </div>
            </div>

            <div style={{ marginBottom: '5px' }}>
                <div style={{ fontSize: '0.8rem', color: '#4dabf7', marginBottom: '5px', display: 'flex', alignItems: 'center', gap: '5px' }}>
                    ❄️ FRÍOS
                </div>
                <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                    {coldNumbers.map((item, i) => (
                        <NumberBadge key={i} number={item.num} size={28} />
                    ))}
                </div>
            </div>
        </div>
    );
};
