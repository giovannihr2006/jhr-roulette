class SoundManager {
    constructor() {
        this.ctx = null
        this.masterGain = null
        this.ambienceNodes = null
        this.ballLoopNodes = null
        this.initialized = false
        this.isMuted = false
    }

    init() {
        if (this.initialized) return
        const AudioContext = window.AudioContext || window.webkitAudioContext
        this.ctx = new AudioContext()
        this.masterGain = this.ctx.createGain()
        this.masterGain.gain.value = 0.4
        this.masterGain.connect(this.ctx.destination)
        this.initialized = true
    }

    setMute(mute) {
        this.isMuted = mute
        if (this.masterGain) {
            this.masterGain.gain.setTargetAtTime(mute ? 0 : 0.4, this.ctx.currentTime, 0.1)
        }
        if (mute) this.stopAmbience()
        else this.startAmbience()
    }

    // --- PROCEDURAL UIs ---

    playChip() {
        try {
            if (!this.initialized) this.init()
            if (this.ctx.state === 'suspended') this.ctx.resume()

            const t = this.ctx.currentTime
            const osc = this.ctx.createOscillator()
            const gain = this.ctx.createGain()

            // Short "click" - High sine + fast decay
            osc.type = 'sine'
            // Randomize pitch slightly for realism
            const freq = 2000 + (Math.random() * 500)
            osc.frequency.setValueAtTime(freq, t)
            osc.frequency.exponentialRampToValueAtTime(500, t + 0.05)

            gain.gain.setValueAtTime(0.2, t)
            gain.gain.exponentialRampToValueAtTime(0.01, t + 0.05)

            osc.connect(gain)
            gain.connect(this.masterGain)

            osc.start()
            osc.stop(t + 0.1)
        } catch (e) { console.warn("Audio Error", e) }
    }

    // --- AMBIENCE (Room Tone) ---

    startAmbience() {
        try {
            if (!this.initialized || this.isMuted || this.ambienceNodes) return
            if (this.ctx.state === 'suspended') this.ctx.resume()

            // Pink Noise buffer for "Room Hiss"
            const bufferSize = 2 * this.ctx.sampleRate
            const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate)
            const output = buffer.getChannelData(0)
            let lastOut = 0
            for (let i = 0; i < bufferSize; i++) {
                const white = Math.random() * 2 - 1
                output[i] = (lastOut + (0.02 * white)) / 1.02
                lastOut = output[i]
                output[i] *= 3.5 // Compensate for gain loss
            }

            const noise = this.ctx.createBufferSource()
            noise.buffer = buffer
            noise.loop = true

            // Lowpass filter to make it "distant"
            const filter = this.ctx.createBiquadFilter()
            filter.type = 'lowpass'
            filter.frequency.value = 400

            const gain = this.ctx.createGain()
            gain.gain.value = 0.05 // Very subtle

            noise.connect(filter)
            filter.connect(gain)
            gain.connect(this.masterGain)

            noise.start()
            this.ambienceNodes = { noise, gain }
        } catch (e) {
            console.warn("Audio Context Error", e)
        }
    }

    stopAmbience() {
        try {
            if (this.ambienceNodes) {
                this.ambienceNodes.gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 1)
                this.ambienceNodes.noise.stop(this.ctx.currentTime + 1)
                this.ambienceNodes = null
            }
        } catch { /* ignore */ }
    }

    // --- BALL ROLLING (Physics Sound) ---

    playBallLoop() {
        try {
            if (!this.initialized) this.init()
            if (this.isMuted) return
            if (this.ctx.state === 'suspended') this.ctx.resume()
            if (this.ballLoopNodes) return // Already playing

            // White Noise Source
            const bufferSize = this.ctx.sampleRate * 2
            const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate)
            const data = buffer.getChannelData(0)
            for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1

            const noise = this.ctx.createBufferSource()
            noise.buffer = buffer
            noise.loop = true

            // Bandpass to simulate "rolling" friction
            const filter = this.ctx.createBiquadFilter()
            filter.type = 'bandpass'
            filter.Q.value = 1
            filter.frequency.value = 800

            // Panner for rotation effect (Left <-> Right)
            const panner = this.ctx.createStereoPanner()
            const lfo = this.ctx.createOscillator()
            lfo.type = 'sine'
            lfo.frequency.value = 0.5 // Revolution speed (approx)

            const gain = this.ctx.createGain()
            gain.gain.setValueAtTime(0, this.ctx.currentTime)
            gain.gain.linearRampToValueAtTime(0.15, this.ctx.currentTime + 1)

            lfo.connect(panner.pan)
            noise.connect(filter)
            filter.connect(panner)
            panner.connect(gain)
            gain.connect(this.masterGain)

            noise.start()
            lfo.start()

            this.ballLoopNodes = { noise, lfo, gain }
        } catch (e) {
            console.warn("Audio Ball Loop Error", e)
        }
    }

    stopBallLoop() {
        try {
            if (this.ballLoopNodes) {
                const t = this.ctx.currentTime
                this.ballLoopNodes.gain.gain.linearRampToValueAtTime(0, t + 0.5)
                this.ballLoopNodes.noise.stop(t + 0.5)
                this.ballLoopNodes.lfo.stop(t + 0.5)
                this.ballLoopNodes = null

                // Trigger "Land" sound
                this.playBallLand()
            }
        } catch (e) { console.warn(e) }
    }

    playBallLand() {
        try {
            const t = this.ctx.currentTime
            const osc = this.ctx.createOscillator()
            const gain = this.ctx.createGain()

            osc.frequency.setValueAtTime(200, t)
            osc.frequency.exponentialRampToValueAtTime(50, t + 0.2)

            gain.gain.setValueAtTime(0.2, t)
            gain.gain.exponentialRampToValueAtTime(0.01, t + 0.2)

            osc.connect(gain)
            gain.connect(this.masterGain)

            osc.start()
            osc.stop(t + 0.2)
        } catch { /* ignore */ }
    }

    playSpinStart() {
        try {
            // Just a little air whoosh
            if (!this.initialized) this.init()
            if (this.isMuted) return

            const osc = this.ctx.createOscillator()
            const gain = this.ctx.createGain()
            osc.frequency.setValueAtTime(100, this.ctx.currentTime)
            osc.frequency.linearRampToValueAtTime(300, this.ctx.currentTime + 0.5)
            gain.gain.setValueAtTime(0.1, this.ctx.currentTime)
            gain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.5)

            osc.connect(gain)
            gain.connect(this.masterGain)
            osc.start()
            osc.stop(this.ctx.currentTime + 0.5)
        } catch { /* ignore */ }
    }

    // --- WIN CELEBRATION ---

    playWin(_amount) {
        try {
            if (!this.initialized || this.isMuted) return

            const t = this.ctx.currentTime
            // Magic Chord (Cmaj9)
            const notes = [523.25, 659.25, 783.99, 987.77, 1046.50]

            notes.forEach((freq, i) => {
                const osc = this.ctx.createOscillator()
                const gain = this.ctx.createGain()

                osc.type = 'triangle'
                osc.frequency.value = freq

                const start = t + (i * 0.05)
                gain.gain.setValueAtTime(0, start)
                gain.gain.linearRampToValueAtTime(0.1, start + 0.1)
                gain.gain.exponentialRampToValueAtTime(0.001, start + 2)

                osc.connect(gain)
                gain.connect(this.masterGain)
                osc.start(start)
                osc.stop(start + 2.5)
            })
        } catch (e) { console.warn("Audio Win Error", e) }
    }

    playRecord() {
        try {
            if (!this.initialized || this.isMuted) return

            const t = this.ctx.currentTime
            // Epic Fanfare (Ascending Triad + High Note)
            const notes = [392.00, 523.25, 659.25, 783.99, 1046.50, 1567.98] // G4, C5, E5, G5, C6, G6

            notes.forEach((freq, i) => {
                const osc = this.ctx.createOscillator()
                const gain = this.ctx.createGain()

                osc.type = i === notes.length - 1 ? 'square' : 'sawtooth' // Lead is square
                osc.frequency.setValueAtTime(freq, t + i * 0.1)

                const start = t + i * 0.1
                gain.gain.setValueAtTime(0, start)
                gain.gain.linearRampToValueAtTime(0.15, start + 0.1)
                gain.gain.exponentialRampToValueAtTime(0.001, start + 2.5)

                osc.connect(gain)
                gain.connect(this.masterGain)

                osc.start(start)
                osc.stop(start + 3)
            })
        } catch (e) {
            console.warn("Audio Record Error", e)
        }
    }
}

export const soundManager = new SoundManager()
