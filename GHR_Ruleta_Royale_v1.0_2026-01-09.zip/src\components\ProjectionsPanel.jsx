import React, { useState, useEffect } from 'react'
import { useFinancialStore } from '../logic/FinancialSimulator'
import { calculateWinnings } from '../logic/RouletteUtils'

const ProjectionsPanel = ({ viewCurrency = 'COL', currentBets = {} }) => {
    const sessionStart = useFinancialStore(state => state.sessionStart)
    const initialCapital = useFinancialStore(state => state.initialCapital) || 0
    const balance = useFinancialStore(state => state.balance)
    const peakCapital = useFinancialStore(state => state.peakCapital) || 0


    // Currency Exchange Rates (Base: 1 Logic Unit = 1 USD)
    const RATES = {
        COL: 100,  // User requested 100
        USA: 1,
        EUR: 0.92  // ~0.92 EUR per USD
    }

    // --- MONTE CARLO SIMULATION ---
    const [simStats, setSimStats] = useState(null)
    const [isSimulating, setIsSimulating] = useState(false)

    // Local ticker to update time
    const [now, setNow] = useState(() => Date.now())
    useEffect(() => {
        const interval = setInterval(() => setNow(Date.now()), 1000)
        return () => clearInterval(interval)
    }, [])

    // Reset stats when bets change
    useEffect(() => {
        setSimStats(null) // eslint-disable-line react-hooks/exhaustive-deps
    }, [currentBets])

    const runSimulation = () => {
        if (!currentBets || Object.keys(currentBets).length === 0) return

        setIsSimulating(true)
        // Set timeout to allow UI to show loading state
        setTimeout(() => {
            let totalProfit = 0
            let wins = 0
            const iterations = 1000

            for (let i = 0; i < iterations; i++) {
                const winningNumber = Math.floor(Math.random() * 37)
                const winnings = calculateWinnings(winningNumber, currentBets)
                const betCost = Object.values(currentBets).reduce((a, b) => a + b, 0)

                if (winnings > 0) wins++
                totalProfit += (winnings - betCost)
            }

            setSimStats({
                ev: totalProfit / iterations,
                winRate: (wins / iterations) * 100
            })
            setIsSimulating(false)
        }, 100)
    }

    // Safety check - MUST BE AFTER HOOKS
    // Safety check - MUST BE AFTER HOOKS
    // if (initialCapital === 0 && balance === 0) return null // REMOVED: User wants to see it always

    // STRICT FORMULA COPY FROM BANKING HUD
    // Profit = Record - Initial
    const profit = peakCapital - initialCapital

    // Time calculation
    const durationMs = now - sessionStart
    const durationMins = Math.max(0.1, durationMs / 60000)

    const profitPerMin = profit / durationMins
    const profitPerHour = profitPerMin * 60
    const profitPerDay = profitPerHour * 8 // User asked for "Day of 8 Hours"
    const profitPerMonth = profitPerDay * 30 // User asked for "Month of 30 Days"
    const profitPerYear = profitPerDay * 360 // User asked for "Year of 360 Days"

    // REVISING FORMATTER TO MATCH CASINO TABLE EXACTLY
    const formatValueExact = (creditValue) => {
        const val = creditValue * (RATES[viewCurrency] || 1)
        if (viewCurrency === 'COL') return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(val)
        if (viewCurrency === 'USA') return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val)
        if (viewCurrency === 'EUR') return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(val)
        return val.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 })
    }

    const items = [
        { label: 'Minuto', val: profitPerMin },
        { label: 'Hora', val: profitPerHour },
        { label: 'Día (8h)', val: profitPerDay },
        { label: 'Mes (30d)', val: profitPerMonth },
        { label: 'Año (360d)', val: profitPerYear },
    ]

    return (
        <div style={{
            background: 'rgba(0,0,0,0.85)',
            border: '1px solid #444',
            borderRadius: '10px',
            padding: '15px',
            color: '#fff',
            fontFamily: 'Roboto, sans-serif',
            width: '320px',
            backdropFilter: 'blur(5px)',
            boxShadow: '0 4px 15px rgba(0,0,0,0.5)'
        }}>
            <h3 style={{
                margin: '0 0 10px 0',
                fontSize: '0.9rem',
                color: '#d4af37',
                textTransform: 'uppercase',
                letterSpacing: '1px',
                borderBottom: '1px solid #444',
                paddingBottom: '5px',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center'
            }}>
                <span>Proyecciones</span>
                {/* Simulation Button */}
                {currentBets && Object.keys(currentBets).length > 0 && (
                    <button
                        onClick={runSimulation}
                        disabled={isSimulating}
                        style={{
                            background: isSimulating ? '#444' : '#222',
                            border: '1px solid #d4af37',
                            color: '#d4af37',
                            fontSize: '0.65rem',
                            padding: '2px 8px',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            textTransform: 'uppercase'
                        }}
                    >
                        {isSimulating ? '...' : 'Simular 1k'}
                    </button>
                )}
            </h3>

            {/* MONTE CARLO RESULTS */}
            {simStats && (
                <div style={{
                    marginBottom: '15px', padding: '10px', background: 'rgba(212, 175, 55, 0.1)',
                    borderRadius: '5px', border: '1px solid #d4af37'
                }}>
                    <div style={{ fontSize: '0.75rem', color: '#d4af37', marginBottom: '5px', fontWeight: 'bold', textTransform: 'uppercase' }}>
                        Análisis Monte Carlo (1000 giros)
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                        <div>
                            <div style={{ fontSize: '0.7rem', color: '#aaa' }}>Retorno Esp. (EV)</div>
                            <div style={{
                                color: simStats.ev >= 0 ? '#4f4' : '#f44',
                                fontWeight: 'bold', fontFamily: 'monospace'
                            }}>
                                {formatValueExact(simStats.ev)}
                            </div>
                        </div>
                        <div>
                            <div style={{ fontSize: '0.7rem', color: '#aaa' }}>Probabilidad</div>
                            <div style={{ color: '#fff', fontWeight: 'bold', fontFamily: 'monospace' }}>
                                {simStats.winRate.toFixed(1)}%
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* EXISTING PROJECTIONS HEADER */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: '1fr 1.2fr 1fr',
                gap: '10px',
                paddingBottom: '10px',
                borderBottom: '2px solid #555',
                marginBottom: '5px',
                fontSize: '0.75rem',
                color: '#888',
                fontWeight: 'bold',
                textTransform: 'uppercase',
                letterSpacing: '1px'
            }}>
                <div>Tiempo</div>
                <div style={{ textAlign: 'right' }}>Ganancia</div>
                <div style={{ textAlign: 'right' }}>Interés</div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {items.map((item) => {
                    // Calculate Interest % relative to Initial Capital
                    const interest = initialCapital > 0 ? (item.val / initialCapital) * 100 : 0

                    return (
                        <div key={item.label} style={{
                            display: 'grid',
                            gridTemplateColumns: '1fr 1.2fr 1fr', // Match header
                            gap: '10px',
                            padding: '8px 0',
                            borderBottom: '1px solid #333',
                            alignItems: 'center'
                        }}>
                            <div style={{ color: '#aaa', fontSize: '0.85rem' }}>{item.label}</div>
                            <div style={{
                                color: item.val > 0 ? '#4f4' : (item.val < 0 ? '#f44' : '#888'),
                                fontWeight: 'bold',
                                textAlign: 'right',
                                fontFamily: 'monospace',
                                fontSize: '0.95rem'
                            }}>
                                {formatValueExact(item.val)}
                            </div>
                            <div style={{
                                fontSize: '0.85rem',
                                color: interest >= 0 ? '#4f4' : '#f44',
                                fontFamily: 'Roboto Mono, monospace',
                                textAlign: 'right'
                            }}>
                                {Math.abs(interest).toFixed(2)}%
                            </div>
                        </div>
                    )
                })}
            </div>

            <div style={{
                marginTop: '10px',
                fontSize: '0.7rem',
                color: '#555',
                textAlign: 'center',
                fontStyle: 'italic'
            }}>
                (Récord - Inicial) / Tiempo
            </div>
        </div>
    )

}

export default ProjectionsPanel
